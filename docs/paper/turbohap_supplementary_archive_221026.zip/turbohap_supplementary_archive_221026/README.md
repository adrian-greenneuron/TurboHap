# TurboHap manuscript: Supplementary File 2

Prepared 2026-10-22. Seven simulated workloads measured 21–22 October 2026.

Start with [turbohap_supplementary_material_221026.pdf](turbohap_supplementary_material_221026.pdf), or its [Markdown edition](turbohap_supplementary_material_221026.md).

- `data/`: all 42 observations, source/build identities, input/truth manifests and output-check records.
- `data/turbohap_haplotype_libraries_221026.json`: final library counts and retained log hashes.
- `reference/findhapV3/`: the exact Fortran reference sources and build instructions.
- `dataset_recipe_221026.md`: the synthetic input-generation recipe.
- `assets/`: four manuscript figures and two performance heatmaps in SVG/PDF/PNG.
- `tools/recalculate_benchmarks.py`: verify checksums and recalculate summaries with Python 3.9+.
- `tools/render_methods_figures.py`: redraw the three schematic figures; requires Matplotlib.
- `tools/render_benchmark_figures.py`: redraw corrected performance plots; requires NumPy and Matplotlib.
- `tools/prepare_simulated_parent_sexes.py`: prepare parent roles before genotype simulation.
- `tools/summarise_haplotype_libraries.py`: extract final library counts from a rerun's console log.
- `tools/benchmark_dataset.py`: rerun one dataset with all three programs, twice each;
  requires Linux, GNU time and GNU sort. Output comparisons use the included
  `compare_outputs.py` and `findhap_options.py`.
- `SHA256SUMS`: SHA-256 for every payload file except this checksum file itself.

From this directory, run `python3 tools/recalculate_benchmarks.py`. This checks the
archive and recorded measurements, then prints summary CSV.
Run it before modifying or regenerating any payload; regenerated files have new hashes.

The source is [TurboHap v1.0.0](https://github.com/adrian-greenneuron/TurboHap/tree/v1.0.0).
The source repository is public. The archive supports offline summary checking.
Inference reruns additionally require the built executables and input data; follow
Section S2 of the supplement. Reruns create new measurements and retain six output sets.
The supplied study measurements remain in `data/`.

All seven synthetic input datasets and simulation truth are available from
[Zenodo (doi:10.5281/zenodo.23566926)](https://doi.org/10.5281/zenodo.23566926)
under CC BY 4.0 as *TurboHap synthetic benchmark datasets and simulation truth*,
version 1.0.0. Raw genotypes, truth and executable binaries are not included here.
The article and figures use CC BY 4.0; TurboHap retains
its custom software licence, and the original Fortran reference is public domain.
