# Fortran reference used for the TurboHap benchmarks

These are the exact FindHap v3 source files used to build the measured Fortran
baseline. They retain the gfortran/ARM64 adaptations used in the study. Their
SHA-256 hashes are recorded in `data/turbohap_build_provenance_221026.json`
at the supplementary archive root.

The original program was written by Paul M. VanRaden at the USDA Agricultural
Research Service, Animal Improvement Programs Laboratory. USDA distributes
FindHap as public-domain software. The original attribution is retained in the
source. See the [USDA FindHap documentation](https://www.ars.usda.gov/northeast-area/beltsville-md-barc/beltsville-agricultural-research-center/agil/aip/software/findhap/).

Build in this directory with GCC/gfortran 13.3.0 on Linux ARM64 to match the
study's toolchain:

```sh
gfortran findhap.f90 nhash.f90 quicksort.f90 -o findhap -O3 -fopenmp -fno-underscoring
```

The included makefile runs the same command. The measured executable's hash
is recorded in the build metadata; executable bytes may differ with another
compiler, linker or runtime. This source is provided for reproduction of the
Fortran comparison, separately from TurboHap's custom software licence.
