recursive subroutine quicksort(a, first, last)
  implicit none
  integer, intent(inout) :: a(*)
  integer, intent(in) :: first, last
  integer :: x, t
  integer :: i, j

  if (first >= last) return
  x = a((first + last) / 2)
  i = first
  j = last
  do
    do while (a(i) < x)
      i = i + 1
    end do
    do while (a(j) > x)
      j = j - 1
    end do
    if (i <= j) then
      t = a(i)
      a(i) = a(j)
      a(j) = t
      i = i + 1
      j = j - 1
    end if
    if (i > j) exit
  end do
  if (first < j) call quicksort(a, first, j)
  if (i < last) call quicksort(a, i, last)
end subroutine quicksort
