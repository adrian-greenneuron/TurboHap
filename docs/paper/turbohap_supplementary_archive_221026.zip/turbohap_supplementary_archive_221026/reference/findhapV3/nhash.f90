integer function nhash (id,mode,idtab,isize,maxn)
  integer mode,nprime/433/,ie/16/,i,j,isize,maxn &
    ,idtab(isize),id
!                                   instructions for hashing:
!                           mode=-1 initiates parameters, zeroes idtab
!                               = 0 looks up id only
!                               = 1 puts new id's into idtab
  if (mode == -1) then
    maxn = 0
    do i=1,isize
      idtab(i) = 0
    enddo
    nhash = -1
    return
  endif
  if (id == 0) then
    nhash = 0
    return
  endif
  nhash = abs(mod(nprime*id,isize)) + 1
  do j = 1,isize
    if (idtab(nhash) == 0) then
      if (mode == 1) then
        idtab(nhash) = id
        maxn = maxn + 1
        if (maxn .gt. .9*isize) then
          print *,'hash table size',isize &
           ,'  is too small, increase it'
          stop 261
        endif
      else
        nhash = 0
      endif
      return
    endif
    if (idtab(nhash) == id) return
    nhash = mod(nhash+ie,isize) + 1
  enddo
  print *,'Function NHASH dropped out of the loop'
  stop 41
end
