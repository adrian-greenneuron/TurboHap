! findhap.f90:                 Haplotyping and imputation with dense SNP markers
!                  version 3:  Can use prior haplotypes to impute only new genotypes,
!                              Combines population and pedigree matching in 1 loop,
!                              Uses multiple haplotype segment lengths 
!
!                              Fortran program written by Paul VanRaden  2009
!                              Animal Improvement Programs Lab, USDA
!                              Paul.VanRaden@ars.usda.gov
!
! OPTION DEFINITIONS:         (reads from findhap.options file)
!                iters     =   maximum number of iterations
!                Xchrom    =   final chromosome number for X, or 0 if no X
!                maxlen    =   maximum number of SNP to include in segment
!                minlen    =   minimum number of SNP to include in segment
!                steps     =   number of steps to get from maxlen to minlen
!                maxhap    =   maximum haplotypes expected in any segment
!                hapout    = 0 does not output haplotypes.txt
!                          = 1 outputs haplotypes.txt for genotyped and imputed animals
!                genout    = 0 does not output genotypes.filled
!                          = 1 outputs genotypes.filled for genotyped and imputed animals
!                          = 2 outputs genotypes.filled with best call (only codes 0, 1, 2)
!                          = 5 outputs genotypes.filled with codes 3 and 4 set to 5
!                damout    = 0 does not impute non-genotyped parents
!                          = 1 outputs imputed genotypes of dams
!                          = 2 outputs imputed genotypes of dams and sires
!                listout   = 0 does not output hap.list or hap.found
!                          = 1 outputs hap.list and hap.found for all steps
!                          =-1 outputs hap.list and hap.found only from last step
!                errate    = x fraction of miscalled genotypes allowed when matching
! COMMAND LINE ARGUMENT:
!                threads   =   number of parallel processors to use
!  USE IFPORT
  use omp_lib
  implicit none
!include "omp_lib.h"
  real,            dimension(:),    allocatable :: freq,basefreq,curfreq
  real,            dimension(:),    allocatable :: linkREL,patREL
  integer(kind=1), dimension(:),    allocatable :: genotype,genovec,genovec2
  integer(kind=1), dimension(:),    allocatable :: haplotype
  integer,         dimension(:),    allocatable :: loc1,locN,prog,gprog,pntloc
  integer,         dimension(:),    allocatable :: locate1,locateN,phaps
  integer,         dimension(:,:),  allocatable :: ped,fromprog,chiplist
  integer,         dimension(:),    allocatable :: loclist,chiplen,called
  integer,         dimension(:),    allocatable :: animkey,nhap,missall,keyvec
  integer,         dimension(:),    allocatable :: listeqn,ids,eqns,missadd
  integer,         dimension(:),    allocatable :: startloc,prevstartloc
  integer,         dimension(:),    allocatable :: len,prevlen,chro,chip,high
  integer,         dimension(:),    allocatable :: startseg,stopseg,proghaps
  integer,         dimension(:),    allocatable :: nfreq,ofreq,sumfreq,birth
  integer,         dimension(:),    allocatable :: bfreq,cfreq,sumbase,sumcurr
  character*1,     dimension(:),    allocatable :: sexv
  character*2,     dimension(:,:,:),allocatable :: patmat
  integer,         dimension(:,:,:),allocatable :: keephap,prevkeephap
  integer(kind=1), dimension(:,:,:),allocatable :: haplist,prevhaplist
  integer(kind=1), dimension(:),    allocatable :: hapseg
  integer,         dimension(:,:),  allocatable :: hapfreq,order
  integer   l, i, j, k, n, m, ii, maxnhap, maxnseg, ngen, nprior
  integer   baseyr, curryr, today, nbase, step, steps, genout, listout
  integer   n15, n16, n25, n31, switch, seg, segs, maxseg, Xseg, hapout, damout
  integer   length, maxlen, minlen, prevmaxlen, maxn, found(2), known
  integer   hapswap, segfirst, seglast, chips, chipn, imputed, status
  character*2 cthrds
  character*2 chro1,chroN,newpatmat(2),matchcode(7)
  character*1 sex
  character*50 markername
  integer*8   location, totlngth, maxlngth
  integer mosthap(0:3),mosthaps(0:3),search,usable
  integer maxped,loci,nloci,maxped2,mismatch,haps,maxhap
  integer chrome,chrome1,chromes,idnum,nhash,prevseg,prevsegs
  integer n13,n13a,hold,cross(2),ncross,pnthap(2),where(2,2)
  integer maxloci,missing,anmlmiss,high1,nhigh,nmed,pedx(2)
  integer loc,locus,nped,iter,iter1,iters,suggest(16),agree
  integer pstep,psegs,haplen,haptot,totlen
  integer(kind=8) :: nped1
  integer nn,pnt,pnt1,pnt2,pnts,grdpnt,bday,nadd,nmale,ndrop
  integer XChrom,match(2,2),matches
  integer totprog,maxprog,maxpnt,hap(2)
  real    simplfreq,corr2,correct,lenratio,errate  !/.004/ for 3K, /.002/ for HD
  real    haptotal
  real*8  totfreq,hapfrq
  integer notfound
  logical :: exist,exist15,exist16,exist22
  integer gencode(0:5,0:5)
  integer*8   genfreq(0:9)
  integer threads,nthr
!  integer :: mkl_domain_get_max_threads,mkl_get_max_threads
  integer :: domain_get_max_threads, get_max_threads
  integer :: command_argument_count

! -------------------------------------------- Do input files exist?
  print *,'Output from findhap.f90'
  print *
  inquire  (file='findhap.options',exist=exist)
  if (.not. exist) then
    print *,'file findhap.options is missing'
    call exit(8)
    stop
    end if
  inquire  (file='pedigree.file',exist=exist)
  if (.not. exist) then
    print *,'file pedigree.file is missing'
    call exit(10)
    stop
    end if
  inquire  (file='genotypes.txt',exist=exist)
  if (.not. exist) then
    print *,'file genotypes.txt is missing'
    call exit(13)
    stop
    end if
  inquire  (file='chromosome.data',exist=exist)
  if (.not. exist) then
    print *,'file chromosome.data is missing'
    call exit(14)
    stop
    end if
! -----------------------------------------------------  Read options file
             open ( 8, file='findhap.options')

  read(8,*)      iters,XChrom,maxlen,minlen,steps,maxhap,hapout,genout,damout,listout
  print *,   '   iters,XChrom,maxlen,minlen,steps,maxhap,hapout,genout,damout,listout'
  print '(10i7)',iters,XChrom,maxlen,minlen,steps,maxhap,hapout,genout,damout,listout
  print *
  read(8,*)
  read(8,*)
  read(8,*)       errate
  print '(f9.6)', errate
  print *,    '   errate'
  print *
! ------------------------------------------------------  Input data files
                    open (10, file='pedigree.file')
                    open (13, file='genotypes.txt')
                    open (14, file='chromosome.data')
!                                                         Haplotype priors
  inquire                   (file='hap.listpriors',exist=exist15)
  inquire                   (file='hap.foundpriors',exist=exist16)
  inquire                   (file='hap.Xseg',exist=exist22)
  if (exist15)      open (15,file='hap.listpriors')
  if (exist16)      open (16,file='hap.foundpriors')

  if (exist15 .and. .not. exist16) print *, &
              'hap.foundpriors file is missing'
  if (exist15 .and. .not. exist22) print *, &
              'hap.Xseg file is missing'
! -----------------------------------------------------  Output data files
                    open (22, file='hap.Xseg')
                    open (23, file='do_not_distrib')
                    open (24, file='hap.filled')
  if (listout /= 0) open (25, file='hap.list')
  if (listout /= 0) open (26, file='hap.found')
                    open (27, file='cross.overs')
                    open (28, file='hap.inherit')
                    open (30, file='allele.frequency')
  if (hapout > 0)   open (29, file='haplotypes.txt')
  if (genout > 0)   open (31, file='genotypes.filled')
! ----------------------------------------------------  Initialize variables
  baseyr = 19900101
  today = 0
  nbase = 0
  missing = 5
!                               genotype code given 2 parent haplotype codes
!                     0 1 2     5
  gencode(0:5,0) =  (/0,3,1,5,5,5/)
  gencode(0:5,1) =  (/3,5,4,5,5,5/)
  gencode(0:5,2) =  (/1,4,2,5,5,5/)
  gencode(0:5,3) =  (/5,5,5,5,5,5/)
  gencode(0:5,4) =  (/5,5,5,5,5,5/)
  gencode(0:5,5) =  (/5,5,5,5,5,5/)
!                                match codes between progeny and parent haps
  matchcode(1) = ' 1'
  matchcode(2) = ' 2'
  matchcode(3) = 'X2'
  matchcode(4) = 'X1'
  matchcode(5) = '-1'
  matchcode(6) = '-2'
  matchcode(7) = ' H'
!                                    match code header lines for hap.inherit
  write (28,*) 'Codes  1 and  2 indicate  progeny hap matches 1st or 2nd parent hap'
  write (28,*) 'Codes -1 and -2 indicate  progeny and parent match except for 1 SNP'
  write (28,*) 'Codes X1 and X2 indicate  crossovers from 2 to 1 or from 1 to 2'
  write (28,*) 'Code   0        indicates progeny hap matches neither hap of parent'
  write (28,*) 'Code   H        indicates progeny hap matches both (parent is homozygous)'
  write (28,*) 'Code  ??        indicates progeny and parents each heterozygous for both haps'
  write (28,*) 'Code  ?1 and ?2 indicate  progeny, parents all heterozygous, set from neighbor segments'
  write (28,*) 'Codes  m and  p indicate  parents known, not genotyped, no match'
  write (28,*) 'Code   .        indicates parent  not known'
  write (28,*) 
  write (28,*) ' progeny chro pnt haplotype_inheritance_codes'

!                                                  Default number of threads
  nthr=omp_get_max_threads()
  threads = min(nthr, 6)
!                                                      Set number of threads
  if (command_argument_count() > 0) then
    call get_command_argument(1,cthrds,length,status)
    if (cthrds(2:2) == ' ') then
      cthrds(2:2) = cthrds(1:1)
      cthrds(1:1) = '0'
      end if
    read (cthrds,*) threads
    print *
    threads = min(nthr, threads)
    end if
! NOTE: omp_set_num_threads() does not work reliably with -fno-underscoring.
!   Thread count is set via num_threads() clause on each !$OMP PARALLEL instead.
!
  print *,'Maximum number of processors set to   ',threads
  print *,'Or set threads by command line argument: findhap 8'
  print *
  print *,'Number of processors available =      ',nthr
  print *,'Can be controlled using:  export OMP_NUM_THREADS=8'
  print *
!                                   Get loci, chromes from chromosome.data
  loci = 0
  chromes = 0
  chrome1 = 99999
  read(14,*,end=5)
  do
    read(14,*,end=5) markername,chrome,nloci,loc,location,chips
    loci = loci + 1
    chrome1 = min (chrome, chrome1)
    chromes = max (chrome, chromes)
    end do
 5 continue
  print *,loci,' loci on ',chromes,' chromosomes' &
         ,' read from chromosome.data'
  rewind 14
  if (Xchrom == 0) Xchrom = chromes + 1
  if (Xchrom < chromes) then
    print *,Xchrom,' X must be last chromosome ',chromes
    stop
    end if
  allocate (loc1(chromes),locN(chromes),chiplist(loci,0:chips+1))
  allocate (locate1(chromes),locateN(chromes))
  allocate (loclist(chips+1),chiplen(chips))
  allocate (startseg(chromes),stopseg(chromes))
  chiplen = 0
  maxloci = 0
  maxlngth = 0
  loc1 = 99999999
  locN = 0
  locate1 = 999999999
  locateN = 0
  loci = 0
! ---------------------------------------------------   Read chromosome.data
  read(14,*,end=10)
  do
    loci = loci + 1
    read(14,*,end=10) markername,chrome,nloci,loc,location,chips &
      ,(loclist(chipn),chipn=1,chips)
    do chipn = 1,chips
      if (loclist(chipn) > 0) then
        chiplist(loclist(chipn),chipn) = loci
        chiplen(chipn) = chiplen(chipn) + 1
        if (chiplen(chipn) /= loclist(chipn)) then
          print *,chiplen(chipn), loclist(chipn), &
            ' marker numbers disagree in chromosome.data, chip ',chipn
          stop
          end if
        end if
      end do
    chiplist(loci,0) = loci
    chiplist(loci,chips+1) = loci
    loc1(chrome) = min(loci,loc1(chrome))
    locN(chrome) = max(loci,locN(chrome))
    locate1(chrome) = min(location,locate1(chrome))
    locateN(chrome) = max(location,locateN(chrome))
    maxloci = max(nloci,maxloci)
    maxlngth = max(maxlngth,locateN(chrome)-locate1(chrome)+1)
    end do
 10 loci = loci - 1
  print *
  print *,missing,' missing genotype code'
! -----------------------------------------   Get maxped from pedigree.file
  maxped = 0
  rewind 10
  do
    read(10,*,end=15) sex,idnum,pnt1,pnt2,bday
    maxped = maxped + 1
    end do
 15 continue
  rewind 10
  print *
  print *,maxped,' animals in pedigree.file (maxped)'
  ngen = 0
!                                               Get ngen from genotypes.txt
  do
    read(13,'(3i10)',end=16) idnum,chipn,loc
    ngen = ngen + 1
    end do
 16 continue
  print *,ngen,' animals in genotypes.txt (ngen)'
  rewind 13
! ---------------------------------------------------------------  allocate
  maxped2 = 2 * maxped
  allocate (ped(2,maxped),ids(maxped2),birth(maxped),called(maxped))
  allocate (animkey(0:maxped),sexv(maxped),eqns(0:maxped2),keyvec(maxped))
  allocate (haplotype(loci),freq(loci),nfreq(loci),sumfreq(loci))
  allocate (genotype(loci),genovec(loci),genovec2(loci),missall(loci))
  allocate (listeqn(0:maxped2),missadd(loci),pntloc(0:maxped))
  allocate (basefreq(loci),curfreq(loci),ofreq(loci),prog(0:maxped))
  allocate (bfreq(loci),cfreq(loci),sumbase(loci),sumcurr(loci))
  allocate (startloc(0:loci),prevstartloc(0:loci),gprog(0:maxped))
  allocate (len(0:loci),prevlen(0:loci),chro(loci))
  allocate (linkREL(0:maxped),patREL(0:maxped))
  allocate (high(maxped), chip(maxped))
  ofreq = 0
  gprog = 0
! -----------------------------------------------------  Read pedigree data
  eqns(0) = 0
  listeqn = 0
  nn = nhash(0,-1,ids,maxped2,maxn)
  animkey(0) = 0
  nped = 0
  do
    read(10,*,end=20) sex,idnum,pnt1,pnt2,bday
    nped = nped + 1
    sexv(nped) = sex
    ped(1,nped) = pnt1
    ped(2,nped) = pnt2
    if(pnt1 <= 0) ped(1,nped) = 0
    if(pnt2 <= 0) ped(2,nped) = 0
    animkey(nped) = idnum
    birth(nped) = bday
    if (bday > today) today = bday
    if (bday < baseyr) nbase = nbase + 1
!                                                           Hash individual
    nn = nhash(idnum,1,ids,maxped2,maxn)
    if (maxn .ne. nped) then
      print *,'Duplicate IDs in pedigree.file !'
      stop
      end if
    eqns(nn) = nped
    end do
 20 print *
!                                            Current animals = last 5 years
  curryr = today - 50000
  if (nbase < 10) baseyr = today
  print *,'latest birthday in pedigree.file (today)     = ',today
  print *,'current frequency includes animals born after  ',curryr
  print *,'   base frequency includes animals born before ',baseyr
  print *
  print *,'     animal       sire         dam'
!                                                              Hash parents
  prog = 0
  maxprog = 0

  do i = 1,nped
    ped(1,i) = eqns(nhash(ped(1,i),0,ids,maxped2,maxn))
    ped(2,i) = eqns(nhash(ped(2,i),0,ids,maxped2,maxn))
    end do ! i
!                                                             Count progeny
  do i = 1,nped
    if (ped(1,i) > 0) prog(ped(1,i)) = prog(ped(1,i)) + 1
    if (ped(2,i) > 0) prog(ped(2,i)) = prog(ped(2,i)) + 1
    if (i <= 10) print *,animkey(i),animkey(ped(1,i)),animkey(ped(2,i))
    end do ! i
  high = 0
  high1 = 0
!                                          Get # animals in hap.foundpriors
  if (exist15) then
    read (16,*,end=30)
    read (16,*,end=30)
    nprior = 0
    do
      read (16,*,end=30) idnum, pnt, pstep
      if (pstep > 1) exit
      nprior = nprior + 1
      end do
 30 print *,nprior/2,' animals with data in hap.foundpriors'
    rewind 16
!                                  Get # high-density animals from hap.Xseg
    read (22,*) high1
    print *, high1,' high-density animals in prior data'
    rewind 22
    end if
  if (maxlen == minlen) steps = 1
! -------------------------------------  Start with maxlen, end with minlen
do step = 1, steps
  if (step == 1) then
    print *
    print *,'Begin with maxlen ', maxlen
!                                            Exponential decrease in length
    lenratio = (1. * maxlen / minlen) ** (1./(steps - 1))
  else
!                                                    Report previous maxhap
    maxnhap = 0
    do seg = 1, maxseg
      if (nhap(seg) > maxnhap) then
        maxnhap = nhap(seg)
        maxnseg = seg
        end if
      end do
    print *
    print '(i8,a,i8,a,i5)',maxnhap,' most haplotypes found in segment ' &
           ,maxnseg,' on chromosome ',chro(maxnseg)
    prevmaxlen = maxlen
    maxlen = nint (maxlen / lenratio)
    print *
    print *,'Step ',step,' change maxlen to ', maxlen
!                                                 Store previous haplotypes
    prevsegs = maxseg
    if (step > 2) deallocate (prevkeephap, prevhaplist)
    allocate (prevkeephap(2,maxped,prevsegs))
    allocate (prevhaplist(prevmaxlen,maxhap,prevsegs))
    prevlen = len
    prevkeephap = keephap
    prevhaplist = haplist
    prevstartloc = startloc
    deallocate (haplist, hapfreq, nhap, keephap, hapseg, &
                proghaps, patmat, order, fromprog, phaps)
    end if

!                                          Divide chromosomes into segments
  print *
  print *,' chromosome      length     markers    segments'
  Xseg = loci
  maxseg = 0
  totlngth = 0
  startloc(0) = 0
  len(0) = 1
  do chrome = chrome1, chromes
    if (loc1(chrome) > locN(chrome)) loc1(chrome) = locN(chrome)
    segs = 1 + (locN(chrome) - loc1(chrome)) / maxlen
    do seg = maxseg + 1, maxseg + segs
      startloc(seg) = startloc(seg - 1) + len(seg - 1)
      len(seg) = (locN(chrome) - startloc(seg) + 1) / (maxseg + segs - seg + 1)
      chro(seg) = chrome
      end do ! seg
    if (chrome == Xchrom) Xseg = maxseg + 1
    startseg(chrome) = maxseg + 1
    stopseg(chrome) = maxseg + segs
    maxseg = maxseg + segs
    print '(4i12)', chrome, locateN(chrome) - locate1(chrome) + 1  &
           , locN(chrome) - loc1(chrome) + 1, segs
    totlngth = totlngth + locateN(chrome) - locate1(chrome) + 1
    end do ! chrome
  print *
  print *,maxseg,' total segments across chromosomes'
  if (step == 1) then
    print *,maxloci,' maximum loci on individual chromosome'
    print *,maxlngth,' physical length of longest chromosome'
    print *,totlngth,' total length of genome processed'
    end if
  print *
  allocate (haplist(maxlen,maxhap,maxseg))
  allocate (hapfreq(maxhap,maxseg), nhap(maxseg))
  allocate (keephap(2,maxped,maxseg), hapseg(2*loci))
  allocate (proghaps(0:maxhap), patmat(2,maxped,maxseg))
  allocate (order(0:maxhap,maxseg), phaps(maxseg))
  allocate (fromprog(2*maxped,maxseg))
  hapfreq = 0
  keephap = 0
  haplist = 0
  order = 0
  nhap = 0
! -------------------------------------------------   Read haplotype priors
  if (exist15) then
    hapfreq = 0
    prevseg = 0
    totlen = 0
    n15 = 0
    i = 0
!                                                       Read haplotype list
    if (step == 1) read (15,*,end=915)
    if (step == 1) read (15,*,end=915)
    do
      read (15,'(2f10.5,i10,2i3,i7,i8,i6,1x,9999999i1)',end=915) &
        hapfrq, haptotal, j, chrome, pstep, seg, &
        startloc(seg), haplen, (haplotype(l),l=1,haplen)
      if (pstep > step) exit
      if (seg /= prevseg) then
        i = 0
        prevseg = seg
        totlen = totlen + haplen
        end if
      i = i + 1
      n15 = n15 + 1
      do l = 1,haplen
        haplist(l,i,seg) = haplotype(l)
        enddo
!                                                        Store prior frequencies
      hapfreq(i,seg) = nint(hapfrq * nprior / 100.)
!                                                         Store input sort order
      order(j,seg) = i
      nhap(seg) = max(i,nhap(seg))
!     if (n15 <= 5) print '(2f10.5,i10,2i3,i7,i8,i6,1x,50i1)', &
!       hapfrq, haptotal, j, chrome, pstep, seg, &
!       startloc(seg), haplen, (haplist(l,j,seg),l=1,min(haplen,50))
      end do ! read 15
915 continue
    print *,n15,' records read from hap.listpriors (unit 15)'
    print *
    if (totlen /= loci) then
      print *,'Loci in chromosome.data and hap.listpriors disagree' &
             ,loci, totlen
      stop
      end if
!                                                       Read haplotypes found
!   print *,'      ID  pnt segments  1st 5 haplotypes'
    if (step == 1) read (16,*,end=916)
    if (step == 1) read (16,*,end=916)
    n16 = 0
    do
      read (16,*,end=916) idnum, pnt, pstep, psegs, (phaps(seg), seg=1,psegs)
      if (pstep > step) exit
      n16 = n16 + 1
      nn = nhash(idnum,0,ids,maxped2,maxn)
      if (eqns(nn) > 0) then
        do seg = 1, psegs
          keephap(pnt,eqns(nn),seg) = order(phaps(seg),seg)
          end do ! seg
        end if
      if (psegs /= maxseg) then
        print *,'Number of segments differ in hap.listpriors',psegs,maxseg
        stop
        end if
!     if (n16 <= 5) print '(i10,2i4,i6,2x,5i7)', &
!       idnum, pnt, pstep, psegs, (phaps(seg), seg=1,5)
      end do ! read 16
916 continue
    print *,n16,' records read from hap.foundpriors (unit 16)'
    print *
    end if
!                                                       Initialize sort order
  do seg = 1,maxseg
    do i = 1,maxhap
      order(i,seg) = i
      end do
    end do
!                                                        Initialize variables
  switch = 1
  suggest = 0
  chip = 0
  proghaps = 0
  fromprog = 0
  patmat = '. '
  nfreq = 0
  bfreq = 0
  cfreq = 0
  genfreq = 0
  sumfreq = 0
  sumbase = 0
  sumcurr = 0
! -----------------------------------------------  Iterate to find haplotypes
  if (iters < 3) iters = 3
  print *
  iter1 = 1
  if (exist15) iter1 = iters

  do iter = iter1, iters
    print *,'Step ',step,'   Haplotype iteration ',iter
!                                              Do not sort in last iterations
    if (iter >= iters / 2) switch = 0
    notfound = 0
    n13 = 0
    nhigh = 0
    nmed = 0
    if (iter > iter1) hapfreq = 0
    called = 0
!                                                          Read genotype data
    do
      read(13,'(3i10,1x,99999999i1)',end=100) idnum,chipn,loc &
        ,(genovec(locus),locus=1,loc)
      nn = nhash(idnum,0,ids,maxped2,maxn)
      if (nn == 0) then
        if (iter == iter1 .and. step == 1) print *, &
          'no pedigree for genotyped animal ',idnum
        cycle
        end if
      n13 = n13 + 1
      listeqn(eqns(nn)) = n13
      chip(eqns(nn)) = chipn
      if (chiplen(chipn) /= loc) then
        print *,'Chip lengths differ in genotypes.txt vs chromosome.data: ', &
        chiplen(chipn),loc,'  for chip ',chipn
        stop
        end if
!                                                 Pad low density to max loci
      genotype = missing
      do locus = 1,loc
        genotype(chiplist(locus,chipn)) = genovec(locus)
        if (genovec(locus) <= 2) then
          called(eqns(nn)) = called(eqns(nn)) + 1
        else
          genotype(chiplist(locus,chipn)) = missing
          end if
        end do
!                                        Fill genotype from previous hap list
      if (step > 1) then
        do seg = 1, prevsegs
          do pnt = 1, 2
            hap(pnt) = prevkeephap(pnt,eqns(nn),seg)
            end do ! pnt
          if (hap(1) > 0 .and. hap(2) > 0) then
            do l = 1, prevlen(seg)
              locus = prevstartloc(seg) + l - 1
              if (genotype(locus) == missing) then
                if (prevhaplist(l,hap(1),seg) /= 1 .and. &
                    prevhaplist(l,hap(2),seg) /= 1) then
                  genotype(locus) = (prevhaplist(l,hap(1),seg)  &
                                  +  prevhaplist(l,hap(2),seg)) / 2
                  end if
                end if
              end do ! l
            end if
          end do ! seg
        end if
! --------------------------------------------------------   Allele frequency
      if (iter == iter1) then
        anmlmiss = 0
!$OMP PARALLEL DO REDUCTION(+: anmlmiss) NUM_THREADS(threads)
        do locus = 1,loci
          if (genotype(locus) /= missing) then
            sumfreq(locus) = sumfreq(locus) + genotype(locus)
            nfreq(locus) = nfreq(locus) + 1
            if (birth(eqns(nn)) >= curryr) then
              sumcurr(locus) = sumcurr(locus) + genotype(locus)
              cfreq(locus) = cfreq(locus) + 1
              end if
            if (step == 1) ofreq(locus) = ofreq(locus) + 1
          else
            anmlmiss = anmlmiss + 1
            end if
          end do ! locus
! end parallel do
!                                                             Count genotypes
        do locus = 1,loci
          genfreq(genotype(locus)) = genfreq(genotype(locus)) + 1
          end do ! locus
!                                             Use only high density in iter 1
        if (anmlmiss <= .6 * loci .or. exist15) then
          nhigh = nhigh + 1
          high(eqns(nn)) = 1
!                                                         Flag medium density
        else
          if (anmlmiss < .95 * loci) high(eqns(nn)) = 2
          cycle
          end if
        end if
!                                       Use medium and high density in iter 2
      if (iter == 2) then
        if (high(eqns(nn)) == 0) then
          cycle
        else
          nmed = nmed + 1
          end if
        end if
! --------------------------------------------------------   Process segments

!$OMP PARALLEL DO PRIVATE(j, k, l, locus, pnt, pedx, suggest, length, found) NUM_THREADS(threads)
      do seg = 1,maxseg
!                                                          Are parents known?
        suggest = 0
        do pnt = 1,2
          pedx(pnt) = ped(pnt,eqns(nn))
          end do ! pnt
!                                              Inheritance of X-specific SNPs
!                                                Dam is both parents of males
        if (sexv(eqns(nn)) == 'M' .and. seg >= Xseg) &
          pedx(1) = pedx(2)
        do pnt = 1,2
          if (pedx(pnt) > 0) then
            if (pnt == 1) patmat(1,eqns(nn),seg) = 'p '
            if (pnt == 2) patmat(2,eqns(nn),seg) = 'm '
!                                                      Are parents genotyped?
            if (listeqn(pedx(pnt)) > 0) then
              if (pnt == 1) patmat(1,eqns(nn),seg) = ' 0'
              if (pnt == 2) patmat(2,eqns(nn),seg) = ' 0'
              end if
!                                                           Parent haplotypes
            do j = 1,2
              suggest((pnt-1)*8 + (j-1)*4 + 1) = keephap(j,pedx(pnt),seg)
              if (keephap(j,pedx(pnt),seg) == 0) then
!
!                                          If parent missing, use grandparent
                if (ped(j,pedx(pnt)) > 0) then
                  do k = 1,2
                    suggest((pnt-1)*8 + (j-1)*4 + (k-1)*2 + 1) &
                       = keephap(k,ped(j,pedx(pnt)),seg)
!
!                               If grandparent missing, use great grandparent
                    if (keephap(k,ped(j,pedx(pnt)),seg) == 0) then
                      if (ped(k,ped(j,pedx(pnt))) > 0) then
                        do l = 1, 2
                          suggest((pnt-1)*8 + (j-1)*4 + (k-1)*2 + l) &
                            = keephap(l,ped(k,ped(j,pedx(pnt))),seg)
                          end do ! l
                        end if
                      end if
                    end do ! k
                  end if
                end if
              end do ! j
            end if
          end do ! pnt
! .........................................................   Find haplotypes
        length = len(seg)
        call listhap (genotype(startloc(seg):(startloc(seg)+len(seg)-1)),  &
          haplist, hapfreq, order, suggest, &
          length, maxlen, nhap, maxhap, seg, maxseg, found, switch, errate)
! .........................................................
        if (switch == 0) then
          length = min(len(seg),100)
!                                          Prevent maternal-paternal reversal
          if (.not. (keephap(1,eqns(nn),seg) == found(2)  &
              .and.  keephap(2,eqns(nn),seg) == found(1))) then
            do j = 1,2
!                                                            Store haplotypes
              keephap(j,eqns(nn),seg) = found(j)
              end do ! j
!           if (n13 <= 5 .and. seg == 1 .and. iter == iters) then
!             print *
!             print '(i9,a,100i1)',animkey(eqns(nn)) &
!                  ,' genotype        ',genotype(startloc(seg):(startloc(seg)+length-1))
!             print '(i9,a,100i1)',found(1),' haplist segment ' &
!                  ,haplist(:length,found(1),seg)
!             print '(i9,a,100i1)',found(2),' haplist segment ' &
!                  ,haplist(:length,found(2),seg)
!             end if
            end if
          end if
        end do ! seg
! end parallel do
      end do ! read 13
 100  continue
! --------------------------------------------------------   Allele frequency
    if (iter == iter1) then
      print *,n13,' records read from file genotypes.txt'
      if (nhigh < n13) then
        print *,nhigh,' high  density genotypes used in iter 1'
        print *,n13 - nhigh,' lower density genotypes used in later iters'
        end if
      print *
      print *,'Frequency of genotype codes input in step ',step
      do i = 0,9
        if (genfreq(i) > 0) print '(i15,a,i2,f12.5,a)',genfreq(i) &
          ,' genotypes with code ',i,100.*genfreq(i)/n13/loci,'%'
        end do
      do locus = 1,loci
        if (nfreq(locus) > 0) then
          freq(locus) = .5 * sumfreq(locus) / nfreq(locus)
        else
          freq(locus) = .5
          end if
        end do ! locus
      print *
      print *,'Allele frequencies estimated'
      print '(10f8.4)',(freq(locus),locus=1,10)
      print *
      end if
    if (iter == 2 .and. nmed < n13 .and. nmed /= nhigh) then
      print *,nmed,' medium and high density genotypes used in iter 2'
      print *,n13 - nmed,' low density genotypes used in iters 3+'
      end if
    rewind 13
    ncross = 0
    if (iter == iters .and. step == steps) &
      write (27,'(a)') ' animkey pntkey segment endloc beginloc new_hap pnthap1 pnthap2'
! -------------------------------------------------  Count genotyped progeny
    if (step == 1 .and. iter == iter1) then
      maxprog = 0
      do i = nped,1,-1
!                                                Animal genotyped or imputed
        if (listeqn(i) > 0 .or. gprog(i) >= 3) then
          do pnt = 1,2
!                                       Parent known, other parent genotyped
            if (ped(pnt,i) > 0 .and. listeqn(ped(3-pnt,i)) > 0) then
              gprog(ped(pnt,i)) = gprog(ped(pnt,i)) + 1
              if (gprog(ped(pnt,i)) > maxprog) then
                maxprog = gprog(ped(pnt,i))
                maxpnt = animkey(ped(pnt,i))
                end if
              end if
            end do ! pnt
          end if
        end do ! i
      if (maxprog > 0) print '(i9,a,i9)',maxprog &
        ,' maximum genotyped progeny for parent id = ',maxpnt
      end if
!
!                                               Set up parent location vector
    totprog = 1
    do i = 1,nped
      if (prog(i) > 0) then
        pntloc(i) = totprog
        totprog = totprog + prog(i)
        if (prog(i) >= maxprog) maxpnt = animkey(i)
        maxprog = max(maxprog,prog(i))
        end if
      end do ! i
    if (step == 1 .and. iter == iter1) then
      print '(i9,a,i9)',maxprog &
        ,' maximum progeny for parent id = ',maxpnt
      print *
      end if
    if (switch == 1) cycle
    suggest = 0
! ..................................  Use previous haplotypes of imputed dams
  do i = 1, nped
    if (step > 1 .and. listeqn(i) == 0 .and. .not. exist15) then
!                                                            Create genotypes
      genotype = 5
      do seg = 1, prevsegs
        do pnt = 1, 2
          hap(pnt) = prevkeephap(pnt,i,seg)
          end do ! pnt
        if (hap(1) > 0 .and. hap(2) > 0) then
          do l = 1, prevlen(seg)
            if (prevhaplist(l,hap(1),seg) .ne. 1 .and. &
                prevhaplist(l,hap(2),seg) .ne. 1) then
              locus = prevstartloc(seg) + l - 1
              genotype(locus) = (prevhaplist(l,hap(1),seg) &
                              +  prevhaplist(l,hap(2),seg)) / 2
              end if
            end do ! l
          end if
        end do ! seg
!$OMP PARALLEL DO PRIVATE(length, l, locus, found, known) NUM_THREADS(threads)
      do seg = 1, maxseg
        known = 0
        do l = 1, len(seg)
          locus = startloc(seg) + l - 1
          if (genotype(locus) .ne. missing) known = known + 1
          end do ! l
! .................................................... Load previous genotype
        length = len(seg)
        if (known > 0) then
          call listhap (genotype(startloc(seg):(startloc(seg)+len(seg)-1)),  &
            haplist, hapfreq, order, suggest, &
            length, maxlen, nhap, maxhap, seg, maxseg, found, switch, errate)
          if (found(1) .ne. found(2)) then
            keephap(1,i,seg) = found(1)
            keephap(2,i,seg) = found(2)
            end if
          end if
! .........................................................
        end do ! seg
! end parallel do
      end if
    end do ! ped
! ----------------------------------------------   Process all animals in ped
    do i = 1,maxped

!$OMP PARALLEL DO PRIVATE(pnt,j,grdpnt,pnthap,mismatch,match,matches,pedx,found,k,cross,where,hold,l,locus) &
!$OMP&   NUM_THREADS(threads)
      do seg = 1,maxseg
        match = 0
        matches = 0
!                                                            Inheritance of X
        do pnt = 1,2
          pedx(pnt) = ped(pnt,i)
          end do ! pnt
        if (sexv(i) == 'M' .and. seg >= Xseg) &
          pedx(1) = pedx(2)
        do j = 1,2
          found(j) = keephap(j,i,seg)
          if (found(j) > 0) then
!                                                       Do haps match parents?
            do pnt = 1,2
              if (pedx(pnt) > 0) then
                do grdpnt = 1,2
                  pnthap(grdpnt) = keephap(grdpnt,pedx(pnt),seg)
                  if (pnthap(grdpnt) == found(j)) then
                    match(j,pnt) = grdpnt
                    cycle
                    end if
!                                                        Check noninheritance
                  if (pnthap(grdpnt) > 0) then
                    mismatch = 0
                    do l = 1,len(seg)
                      if (abs(haplist(l,found(j),seg)  &
                            - haplist(l,pnthap(grdpnt),seg)) > 1) &
                          mismatch = mismatch + 1
                      end do ! l
                    if (mismatch == 1) match(j,pnt) = 4 + grdpnt
                    end if
                  end do ! grdpnt
!                                                           Parent homozygous
                if (pnthap(1) == pnthap(2) .and. match(j,pnt) > 0) &
                    match(j,pnt) = 7
                end if
              end do ! pnt
            end if
          if (match(j,1) > 0 .or. match(j,2) > 0) matches = matches + 1
          end do ! j
!                                                        Check for crossovers
        do j = 1,2
          if (found(j) > 0 .and. matches < 2) then
            do pnt = 1,2
              if (pedx(pnt) > 0) then
                do grdpnt = 1,2
                  pnthap(grdpnt) = keephap(grdpnt,pedx(pnt),seg)
                  end do
                if (pnthap(1) == 0 .or. pnthap(2) == 0) cycle
                do grdpnt = 1,2
                  k = grdpnt
                  cross(grdpnt) = 0
                  where(1,grdpnt) = 0
                  where(2,grdpnt) = len(seg)+1
!                                                  Beginning of right segment
                  do l = 1,len(seg)
                    if (abs(haplist(l,found(j),seg)  &
                          - haplist(l,pnthap(k),seg)) > 1) then
                      cross(grdpnt) = cross(grdpnt) + 1
                      where(2,grdpnt) = l
                      k = 3 - k
!                                                        Other hap must agree
                      if (abs(haplist(l,found(j),seg)  &
                            - haplist(l,pnthap(k),seg)) > 1) &
                         cross(grdpnt) = cross(grdpnt) + 1
                    else
!                                                      Ending of left segment
                      if (abs(haplist(l,found(j),seg)  &
                            - haplist(l,pnthap(3-k),seg)) > 1 &
                         .and. cross(grdpnt) == 0) where(1,grdpnt) = l
                      end if
                    end do ! l
                  end do ! grdpnt
!                                                       Output crossover list
                do grdpnt = 1,2
                  if (cross(grdpnt) == 1 .and. cross(3-grdpnt) > 1) then
                    ncross = ncross + 1
!                                                    Print example crossovers
!                   if (ncross <= 5) then
                    if (.false.) then
                      print '(3(a,i10),2i5)','crossover detected, id ' &
                        ,animkey(i),' pntkey ',animkey(ped(pnt,i)),'   segment',seg,'  end, begin locus ' &
                        ,where(1,grdpnt),where(2,grdpnt)
                      print '(i7,2x,9999i1)' ,found(j), &
                        (haplist(l,found(j),seg),l=1,len(seg))
                      print '(i7,2x,9999i1)' ,pnthap(grdpnt), &
                        (haplist(l,pnthap(grdpnt),seg),l=1,len(seg))
                      print '(i7,2x,9999i1)' ,pnthap(3-grdpnt), &
                        (haplist(l,pnthap(3-grdpnt),seg),l=1,len(seg))
                      end if
                    if (iter == iters .and. step == steps) write (27,'(2i9,6i7)') &
                        animkey(i),animkey(ped(pnt,i)),seg,where(1,grdpnt),where(2,grdpnt), &
                        found(j),pnthap(grdpnt),pnthap(3-grdpnt)
                    if (match(j,pnt) == 0) match(j,pnt) = 2 + grdpnt
!
!                                          Use crossover haps to fill missing
!                                                                Left segment
                    do l = 1, where(1,grdpnt)
                      if (haplist(l,found(j),seg) == 1 .and. &
                          haplist(l,pnthap(grdpnt),seg) /= 1) &
                          haplist(l,found(j),seg) = haplist(l,pnthap(grdpnt),seg)
                      end do ! l
!                                                               Right segment
                    do l = where(2,grdpnt), len(seg)
                      if (haplist(l,found(j),seg) == 1 .and. &
                          haplist(l,pnthap(3-grdpnt),seg) /= 1) &
                          haplist(l,found(j),seg) = haplist(l,pnthap(3-grdpnt),seg)
                      end do ! l
!                                                              Middle segment
!                                                     Fill if both haps agree
                    do l = where(1,grdpnt)+1, where(2,grdpnt)-1
                      if (haplist(l,found(j),seg) == 1 .and. &
                          haplist(l,pnthap(grdpnt),seg) /= 1 .and. &
                          haplist(l,pnthap(1),seg) == haplist(l,pnthap(2),seg)) &
                          haplist(l,found(j),seg) = haplist(l,pnthap(grdpnt),seg)
                      end do ! l
                    end if
                  end do ! grdpnt
                end if
              end do ! pnt
            end if
          end do ! j
!                                         Delete double match for homozygotes
        if (found(1) == found(2)) then
          match(1,2) = 0
          match(2,1) = 0
          end if
!                                      Reverse haps if opposite parents match
        if ((match(1,2) > 0 .and. match(1,1) == 0) .or. &
            (match(2,1) > 0 .and. match(2,2) == 0)) then
          keephap(1,i,seg) = found(2)
          keephap(2,i,seg) = found(1)
          hold = found(1)
          found(1) = found(2)
          found(2) = hold
!                                                Reverse parent match matrix
          hold = match(1,1)
          match(1,1) = match(2,1)
          match(2,1) = hold
          hold = match(2,2)
          match(2,2) = match(1,2)
          match(1,2) = hold
          end if
!                                             Code paternal, maternal alleles
        if ((match(1,1) > 0 .and. match(1,2) == 0) .or. &
            (match(2,2) > 0 .and. match(2,1) == 0)) then
          if (match(1,1) > 0) patmat(1,i,seg) = matchcode(match(1,1))
          if (match(2,2) > 0) patmat(2,i,seg) = matchcode(match(2,2))
!                                                          Fix noninheritance
        if (errate * maxlen >= .2) then
          if (match(1,1) == 5) then
            if (hapfreq(found(1),seg) > hapfreq(keephap(1,pedx(1),seg),seg)) then
              keephap(1,pedx(1),seg) = found(1)
              hapfreq(keephap(1,pedx(1),seg),seg) = hapfreq(keephap(1,pedx(1),seg),seg) - 1
              hapfreq(found(1),seg) = hapfreq(found(1),seg) + 1
            else
              found(1) = keephap(1,pedx(1),seg)
              keephap(1,i,seg) = keephap(1,pedx(1),seg)
              hapfreq(found(1),seg) = hapfreq(found(1),seg) - 1
              hapfreq(keephap(1,pedx(1),seg),seg) = hapfreq(keephap(1,pedx(1),seg),seg) + 1
              end if
            end if
          if (match(1,1) == 6) then
            if (hapfreq(found(1),seg) > hapfreq(keephap(2,pedx(1),seg),seg)) then
              keephap(2,pedx(1),seg) = found(1)
              hapfreq(keephap(2,pedx(1),seg),seg) = hapfreq(keephap(2,pedx(1),seg),seg) - 1
              hapfreq(found(1),seg) = hapfreq(found(1),seg) + 1
            else
              found(1) = keephap(2,pedx(1),seg)
              keephap(1,i,seg) = keephap(2,pedx(1),seg)
              hapfreq(found(1),seg) = hapfreq(found(1),seg) - 1
              hapfreq(keephap(2,pedx(1),seg),seg) = hapfreq(keephap(2,pedx(1),seg),seg) + 1
              end if
            end if
          if (match(2,2) == 5) then
            if (hapfreq(found(2),seg) > hapfreq(keephap(1,pedx(2),seg),seg)) then
              keephap(1,pedx(2),seg) = found(2)
              hapfreq(keephap(1,pedx(2),seg),seg) = hapfreq(keephap(1,pedx(2),seg),seg) - 1
              hapfreq(found(2),seg) = hapfreq(found(2),seg) + 1
            else
              found(2) = keephap(1,pedx(2),seg)
              keephap(2,i,seg) = keephap(1,pedx(2),seg)
              hapfreq(found(2),seg) = hapfreq(found(2),seg) - 1
              hapfreq(keephap(1,pedx(2),seg),seg) = hapfreq(keephap(1,pedx(2),seg),seg) + 1
              end if
            end if
          if (match(2,2) == 6) then
            if (hapfreq(found(2),seg) > hapfreq(keephap(2,pedx(2),seg),seg)) then
              keephap(2,pedx(2),seg) = found(2)
              hapfreq(keephap(2,pedx(2),seg),seg) = hapfreq(keephap(2,pedx(2),seg),seg) - 1
              hapfreq(found(2),seg) = hapfreq(found(2),seg) + 1
            else
              found(2) = keephap(2,pedx(2),seg)
              keephap(2,i,seg) = keephap(2,pedx(2),seg)
              hapfreq(found(2),seg) = hapfreq(found(2),seg) - 1
              hapfreq(keephap(2,pedx(2),seg),seg) = hapfreq(keephap(2,pedx(2),seg),seg) + 1
              end if
            end if
          end if
        end if
!                                                 Both parents have both haps
        if (match(1,1) > 0 .and. match(1,2) > 0 .and. &
            match(2,1) > 0 .and. match(2,2) > 0 .and. &
            match(1,1) < 3 .and. match(1,2) < 3 .and. &
            match(2,1) < 3 .and. match(2,2) < 3 .and. &
            found(1) .ne. found(2)) then
          patmat(1,i,seg) = '??'
          patmat(2,i,seg) = '??'
          end if
!                                                    Fill missing hap of mate
        do pnt = 1,2
!                                         Other parent genotyped or imputable
          if (pedx(pnt) > 0 .and. (listeqn(pedx(3-pnt)) > 0  &
                            .or. gprog(pedx(3-pnt)) > 3)) then
            do j = 1,2
              if ((match(j,3-pnt) > 0 .and. match(3-j,3-pnt) == 0) &
                  .or. match(j,3-pnt) == 7) then
!                                               Store possible hap for parent
                fromprog(pntloc(pedx(pnt)),seg) = found(3-j)
                if (keephap(1,pedx(pnt),seg) == 0 .and. &
                    keephap(2,pedx(pnt),seg) /= found(3-j)) then
                  patmat(pnt,i,seg) = ' 1'
                else
                  if (keephap(2,pedx(pnt),seg) == 0 .and. &
                      keephap(1,pedx(pnt),seg) /= found(3-j)) then
                    patmat(pnt,i,seg) = ' 2'
                    end if
                  end if
                end if
              end do ! j
!                                                     Impute dam from son's X
            if (sexv(i) == 'M' .and. seg >= Xseg) then
              fromprog(pntloc(pedx(2)),seg) = found(1)
              if (keephap(1,pedx(2),seg) == 0) then
                keephap(1,pedx(2),seg) = found(1)
                patmat(1,i,seg) = ' 1'
                end if
              if (keephap(2,pedx(2),seg) == 0 .and. &
                  keephap(1,pedx(2),seg) /= found(1)) then
                keephap(2,pedx(2),seg) = found(1)
                patmat(1,i,seg) = ' 2'
                end if
              patmat(2,i,seg) = ' Y'
              end if
            end if
!                                                     Estimate base frequency
!                                                Animal genotyped, parent not
          if (birth(i) < baseyr .and. listeqn(pedx(pnt)) == 0 &
            .and. found(pnt) > 0) then
            do l = 1, len(seg)
              locus = startloc(seg) + l - 1
              if (haplist(l,found(pnt),seg) /= 1) then
                sumbase(locus) = sumbase(locus) + haplist(l,found(pnt),seg)
                bfreq(locus) = bfreq(locus) + 1
                end if
              end do ! l
            end if
          end do ! pnt
        end do ! seg
! end parallel do
!                                                       Use adjacent segments
      seg = 1
      do chrome = chrome1, chromes
        segs = 1 + (locN(chrome) - loc1(chrome)) / maxlen
        segfirst = 0
        seglast = 0
!                                          Find range of double heterozygotes
        do j = seg, seg + segs - 1
          if (patmat(1,i,j) == '??') then
            if (segfirst == 0) then
              segfirst = j
              seglast  = j
              end if
            if (j == seglast + 1) seglast = j
            end if
          end do ! j
        if (segfirst == 0) then
          seg = seg + segs
          cycle
          end if
!                                            Are neighbor segments consistent?
        do pnt = 1,2
          newpatmat(pnt) = '??'
          if (segfirst > seg) then
!                                              Parent's paternal hap inherited
            if (patmat(pnt,i,segfirst-1) == ' 1' .or. &
                patmat(pnt,i,segfirst-1) == '-1' .or. &
                patmat(pnt,i,segfirst-1) == 'X1') then
              newpatmat(pnt) = '?1'
              end if
!                                              Parent's maternal hap inherited
            if (patmat(pnt,i,segfirst-1) == ' 2' .or. &
                patmat(pnt,i,segfirst-1) == '-2' .or. &
                patmat(pnt,i,segfirst-1) == 'X2') then
              newpatmat(pnt) = '?2'
              end if
            end if
!                                                            Following segment
          if (seglast < seg + segs - 1) then
            if (patmat(pnt,i,seglast+1) == ' 1' .or. &
                patmat(pnt,i,seglast+1) == '-1' .or. &
                patmat(pnt,i,seglast+1) == 'X2') then
              if (newpatmat(pnt) /= '?2') then
                newpatmat(pnt) = '?1'
              else
                newpatmat(pnt) = '??'
                end if
              end if
            if (patmat(pnt,i,seglast+1) == ' 2' .or. &
                patmat(pnt,i,seglast+1) == '-2' .or. &
                patmat(pnt,i,seglast+1) == 'X1') then
              if (newpatmat(pnt) /= '?1') then
                newpatmat(pnt) = '?2'
              else
                newpatmat(pnt) = '??'
                end if
              end if
            end if
          end do ! pnt
!                                               Is either parent phase known?
        do j = segfirst, seglast
          hapswap = 0
          do pnt = 1,2
            if (newpatmat(pnt) == '?1') then
              if (keephap(3-pnt,i,j) == keephap(1,ped(pnt,i),j)) hapswap = 1
              exit
              end if
            if (newpatmat(pnt) == '?2') then
              if (keephap(3-pnt,i,j) == keephap(2,ped(pnt,i),j)) hapswap = 1
              exit
              end if
            end do ! pnt
!                                                        Switch heterozygotes
          if (hapswap == 1) then
            hold = keephap(2,i,j)
            keephap(2,i,j) = keephap(1,i,j)
            keephap(1,i,j) = hold
            end if
!                                                           Reset inheritance
          do pnt = 1,2
            if (keephap(pnt,i,j) == keephap(1,ped(pnt,i),j)) then
              patmat(pnt,i,j) = '?1'
            else
              patmat(pnt,i,j) = '?2'
              end if
            end do ! pnt
          end do ! j
        seg = seg + segs
        end do ! chrome
!                                                      Update parent locations
      do pnt = 1,2
        if (ped(pnt,i) > 0) pntloc(ped(pnt,i)) = pntloc(ped(pnt,i)) + 1
        end do ! pnt
      end do ! i
!                                                    Process progeny by parent
    nhigh = 0
    totprog = 1
    do i = 1,nped
      if (prog(i) > 0) then
        pntloc(i) = totprog
        totprog = totprog + prog(i)
!                                                    Only nongenotyped animals
        if (listeqn(i) == 0) then
          do pnt = 1,2
            pedx(pnt) = ped(pnt,i)
            end do ! pnt
          if (sexv(i) == 'M' .and. seg >= Xseg) &
            pedx(1) = pedx(2)
          do seg = 1,maxseg
            mosthap = 0
            mosthaps = 0
!                                          Do prog and grandparent haps agree?
            do j = 1,prog(i)
              agree = 0
              do pnt = 1,2
                if (pedx(pnt) > 0) then
                  do grdpnt = 1,2
                    if (keephap(grdpnt,pedx(pnt),seg) ==  &
                        fromprog(pntloc(i) + j - 1,seg)) agree = agree + 1
                    end do ! grdpnt
                  end if
                end do ! pnt
!                                                   Count possible haplotypes
              proghaps(fromprog(pntloc(i) + j - 1,seg)) = &
                proghaps(fromprog(pntloc(i) + j - 1,seg)) + 1 + agree
              end do ! j
!                                             Find most frequent 2 haplotypes
            do search = 1,2
              do j = 1,prog(i)
                if (fromprog(pntloc(i) + j - 1,seg) /= mosthap(search - 1) &
                .and. proghaps(fromprog(pntloc(i) + j - 1,seg)) > mosthaps(search) &
                .and. fromprog(pntloc(i) + j - 1,seg) > 0) then
                  mosthap(search) = fromprog(pntloc(i) + j - 1,seg)
                  mosthaps(search) = proghaps(fromprog(pntloc(i) + j - 1,seg))
                  end if
                end do ! j
              end do ! search
!           if ((mosthap(1) > 0 .or. mosthap(2) > 0) .and. seg == 1 .and. prog(i) >= 4) then
!             print *,animkey(i),' mosthap = ',mosthap(1),mosthap(2)
!             print *,animkey(i),' keephap = ',keephap(1,i,seg),keephap(2,i,seg)
!             end if
!                                                           Store haplotypes
            if (keephap(1,i,seg) /= mosthap(2) .and. &
                keephap(2,i,seg) /= mosthap(1)) then
              if (step == 1 .or. keephap(1,i,seg) == 0 &
                            .or. keephap(2,i,seg) == 0) then
                keephap(1,i,seg) = mosthap(1)
                keephap(2,i,seg) = mosthap(2)
                end if
              end if
!                                                                Homozygotes
            if ((mosthaps(1) >= 8 .and. mosthaps(2) == 0) .or. &
               (sexv(i) == 'M' .and. seg >= Xseg)) &
              keephap(2,i,seg) = keephap(1,i,seg)
!                                                      Zero the count vector
            do j = 1,prog(i)
              proghaps(fromprog(pntloc(i) + j - 1,seg)) = 0
              end do ! j
            end do ! seg
          end if
        end if
!                                                         Count high density
      if (called(i) > .4 * loci) nhigh = nhigh + 1
      end do ! i
!                                                         End iteration loop
    end do ! iter
! ----------------------------------------------   Write haplotypes inherited
  if (step == steps) then
    print *
    high1 = max(high1, nhigh)
    write (22,*) high1,' high-density genotypes in reference'
    write (22,*) Xseg,' segment where X-specific loci begin'
    write (24,*) '                  total     markers   total SNP'
    write (24,*) '   animal  chip  progeny    observed    filled  corr2(est,true)'
    print *,'First 10 genotypes created'
    print *
    hapfreq = 0
    n13a = 0
    n31 = 0
    missall = 0
    missadd = 0
    nadd = 0
    nmale = 0
    ndrop = 0
    genfreq = 0
    nped1 = nped
    idnum = 0
    keyvec = animkey(1:nped)

    CALL quicksort (keyvec, 1, nped1)
!   call qsort_(keyvec,nped1,4,cpr4)     May be an alternative
!   call insertion_sort(animkey(1:nped)) May be another alternative

    if (nped1 /= nped) print*,'nped1 /= nped',nped1,nped
!                                                  All animals in pedigree
    do ii = 1,nped
      i = eqns(nhash(keyvec(ii),0,ids,maxped2,maxn))
      imputed = 0
      haps = 0
!                                      Count filled haplotypes and markers
      do seg = 1,maxseg
        do pnt = 1,2
          if (keephap(pnt,i,seg) > 0) then
            haps = haps + 1
            do loc = 1, len(seg)
              if (haplist(loc,keephap(pnt,i,seg),seg) .ne. 1) &
                imputed = imputed + 1
              end do ! loc
            end if
          end do ! pnt
        end do ! seg
!                                  Include called heterozygotes in imputed
      if (listeqn(i) > 0 .and. high(i) == 1) then
        imputed = max(imputed/2,called(i))
      else
        imputed = imputed/2
        end if
!                                            Corr**2 (est, true genotype)
      if (called(i) > 0) then
!                                       Adjust for number of high density
        correct = high1 / (high1 + 50.)
!                                      Adjust for SNPs in less dense chip,
!                                    density is fraction of genome length
        correct = correct * called(i) / (called(i) + 120.*totlngth/3.d9)
        corr2 = (.9998 * called(i) + correct * (loci - called(i))) / loci
      else
!                                                            Imputed dams
        correct = gprog(i) / (gprog(i) + 1.)
        corr2 = (.9998 * called(i) + correct * (imputed - called(i))) / loci
        end if
      usable = 0
!                                                        Usable genotypes
      if (corr2 > .84**2) then
!                                      Genotyped animals and imputed dams
        if (listeqn(i) > 0) usable = 1
        if (damout >= 1 .and. sexv(i) == 'F') usable = 1
        if (damout == 2 .and. sexv(i) == 'M') usable = 1
!                                             Males that could be imputed
        if (listeqn(i) == 0 .and. sexv(i) == 'M') nmale = nmale + 1
      else
        if (listeqn(i) > 0) ndrop = ndrop + 1
        end if
!                                        Write hap.found for imputed dams
      if (usable == 1) then
        do pnt = 1,2
          if (listeqn(i) == 0) then
            write (26,'(i10,i2,i3,i6,3x,99999(1x,i0))') &
              animkey(i),pnt,steps,maxseg,(keephap(pnt,i,seg),seg = 1,maxseg)
            do seg = 1,maxseg
              if (keephap(pnt,i,seg) > 0) hapfreq(keephap(pnt,i,seg),seg) &
                                        = hapfreq(keephap(pnt,i,seg),seg) + 1
              end do ! seg
            end if
          end do ! pnt
!                                                        Write hap.filled
        write (24,'(i10,i5,i8,2i12,f8.4)') &
          animkey(i),chip(i),gprog(i),called(i),imputed,corr2
      else
!                                      Unusable genotypes (do_not_distrib)
        if (listeqn(i) > 0) write (23,'(i10,i5,i8,2i12,f8.4)') &
          animkey(i),chip(i),gprog(i),called(i),imputed,corr2
        end if
      do chrome = chrome1, chromes
        do pnt = 1,2
          if (usable == 1) &
            write (28,'(i10,i4,i2,2x,9999a2)') &
              animkey(i),chrome,pnt,(patmat(pnt,i,seg), &
              seg=startseg(chrome),stopseg(chrome))
          end do ! pnt
        end do ! chrome
! ----------------------------------  Create genotypes.filled from haplotypes
      if (usable == 1) then
        do seg = 1, maxseg
          do loc = 1, len(seg)
            locus = startloc(seg) + loc - 1
            if (keephap(1,i,seg) > 0 .and. keephap(2,i,seg) > 0) then
              if (haplist(loc,keephap(1,i,seg),seg) .ne. 1 .and. &
                  haplist(loc,keephap(2,i,seg),seg) .ne. 1) then
                genotype(locus) = (haplist(loc,keephap(1,i,seg),seg) &
                                 + haplist(loc,keephap(2,i,seg),seg)) / 2
              else
                genotype(locus) = missing
                end if
            else
              genotype(locus) = missing
              end if
            do pnt = 1,2
              if (keephap(pnt,i,seg) > 0) then
                pnthap(pnt) = haplist(loc,keephap(pnt,i,seg),seg)
              else
                pnthap(pnt) = missing
                end if
              end do ! pnt
            genotype(locus) = gencode(pnthap(1),pnthap(2))
!                                                 Male X homozygous or missing
            if (sexv(i) == 'M' .and. seg >= Xseg) then
              if (genotype(locus) == 1 .or. genotype(locus) > 2) &
                genotype(locus) = 5
              end if
            end do ! loc
          end do ! seg
        end if
!                                                  Process in ID sorted order
!                                                        Reread genotype data
      if (idnum < keyvec(ii)) then
        read(13,'(3i10,1x,99999999i1)',end=200) idnum,chipn,loc &
          ,(genovec(locus),locus=1,loc)
        nn = nhash(idnum,0,ids,maxped2,maxn)
        if (nn == 0) go to 200
!                                                 Pad low density to max loci
        genovec2(:loci) = missing
        do locus = 1,loc
          if (genovec(locus) > 2) genovec(locus) = missing
          genovec2(chiplist(locus,chipn)) = genovec(locus)
          end do
        end if
      if (idnum == keyvec(ii)) then
        n13a = n13a + 1
        do locus = 1,loci
!                                                    Restore called genotypes
          if (genovec2(locus) == 0) genotype(locus) = 0
          if (genovec2(locus) == 1) genotype(locus) = 1
          if (genovec2(locus) == 2) genotype(locus) = 2
          end do
        end if
 200  continue
      if (usable == 1) then
        n31 = n31 + 1
        if (n31 <= 10) print '(i10,2x,50i1)',animkey(i),(genotype(loc),loc=1,50)
        if (listeqn(i) == 0) nadd = nadd + 1
!                                                       Count genotype codes
        do locus = 1,loci
          genfreq(genotype(locus)) = genfreq(genotype(locus)) + 1
!                                                       Set code 3 and 4 to 5
          if (genout == 5 .and. genotype(locus) > 2) genotype(locus) = 5
!                                                     Or use freq for missing
          if (genout == 2) then
            if (genotype(locus) == 3) genotype(locus) = freq(locus) + .5
            if (genotype(locus) == 4) genotype(locus) = freq(locus) + 1.5
            if (genotype(locus) == 5) then
              genotype(locus) = 1
              if (freq(locus) < .3333) genotype(locus) = 0
              if (freq(locus) > .6666) genotype(locus) = 2
              end if
            end if
!                                                         Count missing loci
          if (genotype(locus) == missing) then
            missall(locus) = missall(locus) + 1
            if (listeqn(i) == 0) missadd(locus) = missadd(locus) + 1
            end if
          end do ! locus
!                                                      Write genotypes.filled
        if (genout > 0) write (31,'(3i10,1x,999999999i1)') &
          animkey(i),chip(i),loci,(genotype(loc),loc=1,loci)
        end if
! -----------------------------------------------------  Write haplotypes.txt
      if (hapout == 1 .and. usable == 1) then
        m = 0
        do seg = 1,maxseg
          do l = 1,len(seg)
            do k = 1,2
              m = m + 1
!                                                            Look up segments
              if (keephap(k,i,seg) > 0) then
                hapseg(m) = haplist(l,keephap(k,i,seg),seg)
              else
                hapseg(m) = 1
                end if
!                                          Force genotyped to be heterozygous
              if (hapseg(m) == 1) then
                hapseg(m) = k
!                                                          Or use allele freq
                if (listeqn(i) == 0) then
                  if (freq(startloc(seg) + l - 1) < .33333) hapseg(m) = 1
                  if (freq(startloc(seg) + l - 1) > .66666) hapseg(m) = 2
                  end if
              else
!                                                        Convert 0-1-2 to 1-2
                hapseg(m) = hapseg(m) / 2 + 1
                end if
              end do ! k
            end do ! l
          end do ! seg
        write (29,'(3i10,1x,999999i1)') animkey(i),1,loci,  &
          (hapseg(m),m=1,2*loci)
        end if
      end do ! ii
    print *
    print *,n13a,' genotype records rematched to output'
    if (n13a .ne. n13) print *,n13,' genotype records expected - MUST SORT BY ID'
    end if ! step = 1
! ----------------------------------------------------  Write haplotype list
    print *
    if (step == steps) print *,'   hap   freq  haplotype'
    if (listout /= 0) then
      if (step == 1) write (25,'(31x,i3,1x,a)') steps,'steps'
      if (step == 1) write (25,'(a)') &
        '  hap_freq  tot_freq    hap_# chro step seg   locus  lngth  haplotypes'
      if (step == 1) write (26,'(10x,i3,1x,a)') steps,'steps'
      if (step == 1) write (26,*) &
        ' animal  pnt step segments haplotypes'
      end if
!                                                            Write hap.found
    do i = 1,nped
      if (listeqn(i) > 0) then
        do pnt = 1,2
          if (listout == 1 .or. (listout == -1 .and. step == steps)) &
            write (26,'(i10,i2,i3,i6,3x,99999(1x,i0))') &
              animkey(i),pnt,step,maxseg,(keephap(pnt,i,seg),seg = 1,maxseg)
          do seg = 1,maxseg
            if (keephap(pnt,i,seg) > 0) hapfreq(keephap(pnt,i,seg),seg) &
                                      = hapfreq(keephap(pnt,i,seg),seg) + 1
            end do ! seg
          end do ! pnt
        end if
      end do ! i
    n25 = 0
    do seg = 1,maxseg
      totfreq = 0.d0
      haptot = 0
      do i = 1,maxhap
        haptot = haptot + max(hapfreq(i,seg),0)
        end do ! i
      n = 0
!                                                             Write hap.list
      do i = 1,maxhap
        totfreq = totfreq + 1.*hapfreq(order(i,seg),seg)/haptot
        if (hapfreq(order(i,seg),seg) > 0) then
          n = n + 1
          if (listout == 1 .or. (listout == -1 .and. step == steps)) &
            write (25,'(2f10.5,i10,2i3,i7,i8,i6,1x,9999999i1)') &
              100.*hapfreq(order(i,seg),seg)/haptot,100.*totfreq,order(i,seg),chro(seg), &
              step,seg,startloc(seg),len(seg),(haplist(l,order(i,seg),seg),l=1,len(seg))
          n25 = n25 + 1
          if (n <= 20 .and. seg == 1 .and. step == steps)  &
            print '(2i7,2x,9999i1)',i,hapfreq(order(i,seg),seg) &
            ,(haplist(l,order(i,seg),seg),l=1,min(len(seg),100))
          maxnhap = max(order(i,seg),maxnhap)
          end if
        end do ! i
        nhap(seg) = n
      end do ! seg
!                                                                End of step
    if(step < steps .and. listout /= 0) then 
      write (25,'(2f10.5,i10,2i3,i7,i8,i6)') 0.,0.,0,0,step+1,0,0,0
      write (26,'(i10,i2,i3,i6)') 0,0,step+1,0
      end if
  end do ! step
! -------------------------------------------------------- Genotype frequency
    print *
    print *,'Frequency of codes in genotypes.filled'
    do i = 0,9
      if (genfreq(i) > 0) print '(i15,a,i2,f12.5,a)',genfreq(i) &
        ,' genotypes with code ',i,100.*genfreq(i)/n31/loci,'%'
      end do
    if (genout == 5) print *,'Codes 3 and 4 written as code 5 with option genout = 5'
    if (genout == 2) print *,'Codes 3, 4, 5 written as 0, 1, 2 by best call with option genout = 5'
    print *
    print *,maxnhap,' maximum haplotype number within segment'
    print *
    print *,'         Starting marker within each segment'
    segs = 1 + (locN(1) - loc1(1)) / maxlen
    print '(3x,9999i7)',(i,i=1,segs)
    print *,'Chrome'
    seg = 1
    do chrome = chrome1, chromes
      segs = 1 + (locN(chrome) - loc1(chrome)) / maxlen
      print '(i3,9999i7)',chrome,(startloc(i),i=seg,seg + segs - 1)
      seg = seg + segs
      end do ! chrome
    print *
    print *,'         Number of haplotypes found within each segment'
    segs = 1 + (locN(1) - loc1(1)) / maxlen
    print '(3x,9999i7)',(i,i=1,segs)
    print *,'Chrome'
    seg = 1
    do chrome = chrome1, chromes
      segs = 1 + (locN(chrome) - loc1(chrome)) / maxlen
      print '(i3,9999i7)',chrome,(nhap(i),i=seg,seg + segs - 1)
      seg = seg + segs
      end do ! chrome
  print *
  if (genout > 0) print *,n31,' records written to genotypes.filled'
  if (damout == 2) nadd = nadd - nmale
  if (damout >= 1) print *,nadd,' female ancestor genotypes imputed from progeny'
  if (damout == 2) print *,nmale,' male ancestor genotypes imputed from progeny'
  if (nmale > 0) print *,nmale,' male ancestor genotypes that could be imputed'
  print *,ndrop,' genotyped animals with poor imputation not distributed'
  if (nadd == 0) nadd = 1
! --------------------------------------------------------   Allele frequency
  write (30,*) '          allele_frequency_estimates    missing_genotype_frequency'
  write (30,*) '   locus   simple     base  current    input   output  imputed      all'
  do locus = 1,loci
    if (cfreq(locus) > 0) then
      curfreq(locus) = .5 * sumcurr(locus) / cfreq(locus)
    else
      curfreq(locus) = .5
      end if
    if (bfreq(locus) >= 10) then
      basefreq(locus) = .5 * sumbase(locus) / bfreq(locus)
    else
      basefreq(locus) = curfreq(locus)
      end if
    freq(locus) = min(freq(locus),.99999)
    freq(locus) = max(freq(locus),.00001)
    curfreq(locus) = min(curfreq(locus),.99999)
    curfreq(locus) = max(curfreq(locus),.00001)
    basefreq(locus) = min(basefreq(locus),.99999)
    basefreq(locus) = max(basefreq(locus),.00001)
    write (30,'(i9,7f9.6)') locus, freq(locus), basefreq(locus), &
      curfreq(locus), 1. - 1.*ofreq(locus)/n13, &
      1.*(missall(locus) - missadd(locus))/(n31 - nadd), &
      1.*missadd(locus)/nadd, 1.*missall(locus)/n31
    end do ! locus
  print *
  print *,'Program findhap completed normally'
  stop
  end
!----------------------------------------------------------------------------
!                                                    Find haplotype from list
!                                                               Paul VanRaden
!$ recursive &                 
  subroutine listhap (storeseg, haplist, hapfreq, order, suggest, &
    len, maxlen, nhap, maxhap, seg, maxseg, found, switch, errate)
  implicit none
  integer*1 segment(maxlen), haplist(maxlen,maxhap,maxseg)
  integer*1 storeseg(maxlen)
  integer   nhap(maxseg), suggest(16), sugnum, fnd
  integer   hapfreq(maxhap,maxseg), switch
  integer   len, maxlen, maxhap, found(2), i, j, l, m, miss
  integer   fill(maxlen), minfreq, minhap, starti, stopi
  integer   maxseg, seg, startj, ii, hold, check
  integer   order(0:maxhap,maxseg), conflicts, conflict(maxlen)
  real      errate
  sugnum=16
!                                                        Set missing SNP to 1
  check = 0
  do l = 1,len
    segment(l) = storeseg(l)
    if (segment(l) == 5) segment(l) = 1
!                                                        Count checkable loci
    if (segment(l) /= 1) check = check + 1
    end do ! l
  starti = 1
!                               Use suggested haps if locations not switching
  if (switch == 0) then
    startj = 1
  else
    startj = sugnum + 1
    end if
  minhap = 1
  fnd = 0
!                                                           Find 2 haplotypes
  do j = startj,sugnum + 2
    if (j <= sugnum) then
!                                            Parent or grandparent haplotypes
      if (suggest(j) > 0) then
        starti = suggest(j)
        stopi  = suggest(j)
!                                                  First parent already found
        if (fnd == 1 .and. j <= sugnum / 2) cycle
      else
        cycle
        end if
    else
!                                                    or population haplotypes
      if (j == sugnum + 1) starti = 1
      stopi = nhap(seg)
      end if
    minfreq = 99999999
!                                              Search list in frequency order
    do i = starti,stopi
      if (j <= sugnum) then
        ii = i
      else
        ii = order(i,seg)
        if (ii == 0) cycle
        end if
      if (hapfreq(ii,seg) < minfreq) then
        minfreq = min(hapfreq(ii,seg),minfreq)
        minhap = i
        end if
      miss = 0
      conflicts = 0
!                                   Check for opposite homozygotes in segment
      do l = 1, len
        if (abs(segment(l) - haplist(l,ii,seg)) > 1) then
          conflicts = conflicts + 1
          if (conflicts > errate * (check - miss) .or. switch == 1) go to 50
          conflict(conflicts) = l
        else
!                                                               Store missing
          if (haplist(l,ii,seg) == 1 .and. segment(l) /= 1) then
            miss = miss + 1
            fill(miss) = l
            end if
          end if
        end do ! l
!                                                           No checkable loci
      if (check - miss == 0 .and. check > 0) cycle
!                                              Whole segment equals haplotype
      if (conflicts > 0) then
!                                                    Set conflicts to missing
        do m = 1, conflicts
          storeseg(conflict(m)) = 5
          end do ! m
        end if
      if (miss > 0) then
!                                       Fill missing values in haplotype list
        do m = 1, miss
          haplist(fill(m),ii,seg) = segment(fill(m))
          end do ! m
        end if
!                                              Location of matching haplotype
      fnd = fnd + 1
      found(fnd) = ii
      hapfreq(ii,seg) = hapfreq(ii,seg) + 1
      check = 0
!                                               Backsolve for other haplotype
      do l = 1, len
        segment(l) = 2 * segment(l) - haplist(l,ii,seg)
!                                                            Set missing to 1
        if (storeseg(l) == 5) segment(l) = 1
        if (segment(l) /= 1) check = check + 1
        end do ! l
!                                               Switch order if more frequent
      if (hapfreq(ii,seg) > hapfreq(order(minhap,seg),seg) &
         .and. switch == 1) then
        hold = order(minhap,seg)
        order(minhap,seg) = order(i,seg)
        order(i,seg) = hold
      else
        minhap = i
        end if
      go to 75
 50   continue
      end do ! i
!                                                       No matching haplotype
    if (j > sugnum) then
      fnd = fnd + 1
      nhap(seg) = nhap(seg) + 1
      found(fnd) = nhap(seg)
      minhap = nhap(seg)
      if (nhap(seg) > maxhap) then
        print *
        print *,'More haplotypes than maxhap = ',maxhap,' in segment ',seg
        print *,'Increase maxhap in findhap.options'
        call exit (100)
        end if
      hapfreq(nhap(seg),seg) = 1
!                                                         Store new haplotype
      do l = 1, len
        haplist(l,nhap(seg),seg) = segment(l)
        end do ! l
      end if
 75 continue
!                                           Starting location for next search
    if (fnd == 2) exit
    if (j == sugnum + 1) then
      starti = minhap
    else
      minhap = 1
      end if
    end do ! j
! -------------------------------------- Backsolve for 1st from 2nd haplotype
  do l = 1, len
    if (storeseg(l) == 5 .or. haplist(l,found(2),seg) == 1) then
!                                                            Set missing to 1
      segment(l) = 1
    else
      segment(l) = 2 * storeseg(l) - haplist(l,found(2),seg)
      end if
    end do ! l
!                                   Check for opposite homozygotes in 1st hap
  miss = 0
  do l = 1, len
    if (abs(segment(l) - haplist(l,found(1),seg)) > 1) then
      return
!                                                    List loci not yet filled
    else
      if (haplist(l,found(1),seg) == 1 .and. segment(l) /= 1) then
        miss = miss + 1
        fill(miss) = l
        end if
      end if
    end do ! l
!                                          Whole segment equals 1st haplotype
      if (miss > 0) then
!                                        Fill missing values in lst haplotype
        do m = 1, miss
          haplist(fill(m),found(1),seg) =  segment(fill(m))
          end do ! m
        end if
! ---------------------------------------------------------------------------
  return
  end
