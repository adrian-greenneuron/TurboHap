#!/usr/bin/env python3
"""Render schematic methods figures; no benchmark or genotype inputs are read."""
from pathlib import Path
import os
import tempfile
os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "turbohap-paper-matplotlib"))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle

OUT = Path(__file__).resolve().parents[1] / 'assets'
DATE = '211026'
C = dict(ink='#172c44', muted='#4f6070', blue='#287ac1', teal='#087e8b',
         purple='#8452a3', orange='#cf701d', red='#aa3e36', green='#247556',
         pale='#f5f8fb', line='#ccd5de', bluebg='#edf4fc', tealbg='#ebf7f6',
         purplebg='#f4eef8', redbg='#fbeeed', greenbg='#edf7f0', gray='#eef1f4')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':13.5,
    'svg.fonttype':'none','svg.hashsalt':'turbohap-methods-211026',
    'pdf.fonttype':42,'ps.fonttype':42,'savefig.facecolor':'white'})

def txt(ax,x,y,s,size=13.5,color=None,weight='normal',ha='left',va='center',**kw):
    return ax.text(x,y,s,fontsize=size,color=color or C['ink'],weight=weight,
                   ha=ha,va=va,linespacing=1.35,**kw)

def rect(ax,x,y,w,h,fill='white',edge=None,lw=1.4,rounding=.10,**kw):
    p=FancyBboxPatch((x,y),w,h,boxstyle=f'round,pad=0,rounding_size={rounding}',
                     facecolor=fill,edgecolor=edge or C['line'],linewidth=lw,**kw)
    ax.add_patch(p);return p

def arrow(ax,a,b,color=None,lw=1.9,style='-|>',rad=0,**kw):
    p=FancyArrowPatch(a,b,arrowstyle=style,mutation_scale=16,linewidth=lw,
                     color=color or C['muted'],connectionstyle=f'arc3,rad={rad}',
                     shrinkA=1,shrinkB=1,**kw)
    ax.add_patch(p);return p

def route(ax,points,color=None,lw=1.8,dashed=False):
    color=color or C['muted']
    xs,ys=zip(*points[:-1]);ax.plot(xs,ys,color=color,lw=lw,
        linestyle='--' if dashed else '-',solid_capstyle='round')
    arrow(ax,points[-2],points[-1],color=color,lw=lw,
          linestyle='--' if dashed else '-')

def canvas(height,title,subtitle):
    fig,ax=plt.subplots(figsize=(14,height))
    fig.subplots_adjust(left=0,right=1,bottom=0,top=1)
    ax.set(xlim=(0,14),ylim=(0,height));ax.axis('off')
    txt(ax,.4,height-.42,title,23,weight='bold')
    txt(ax,.4,height-.88,subtitle,14,color=C['muted'])
    return fig,ax

def panel(ax,x,y,w,h,label,title):
    rect(ax,x,y,w,h,fill=C['pale'])
    txt(ax,x+.20,y+h-.35,label,16,color=C['blue'],weight='bold')
    txt(ax,x+.62,y+h-.35,title,16,weight='bold')

def save(fig,name,*,date=DATE,dpi=190,creator='TurboHap methods figure renderer'):
    OUT.mkdir(parents=True,exist_ok=True)
    # SVG text remains editable. PDF embeds fonts. Generated dates are omitted.
    for ext in ('png','svg','pdf'):
        metadata={'Creator':creator}
        if ext=='svg':metadata={'Creator':creator,'Date':None}
        elif ext=='pdf':metadata.update(CreationDate=None,ModDate=None)
        fig.savefig(OUT/f'{name}_{date}.{ext}',dpi=dpi,metadata=metadata)
    fig.canvas.draw()
    bounds=fig.bbox
    outside=[]
    for ax in fig.axes:
        for t in ax.texts:
            b=t.get_window_extent(fig.canvas.get_renderer())
            if b.x0<bounds.x0-1 or b.y0<bounds.y0-1 or b.x1>bounds.x1+1 or b.y1>bounds.y1+1:
                outside.append(t.get_text())
    if outside:raise RuntimeError(f'Text outside figure: {outside}')
    plt.close(fig)


def diagram_canvas(height, title, subtitle):
    # Remove unused header space without scaling the panels or their text.
    height -= .32
    fig, ax = plt.subplots(figsize=(14, height))
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
    ax.set(xlim=(0, 14), ylim=(0, height))
    ax.axis('off')
    txt(ax, .4, height-.43, title, 25, weight='bold')
    txt(ax, .4, height-.96, subtitle, 17, color=C['muted'])
    return fig, ax

def diagram_panel(ax, x, y, w, h, letter, title):
    rect(ax, x, y, w, h, fill=C['pale'])
    txt(ax, x+.22, y+h-.35, letter, 19, color=C['blue'], weight='bold')
    txt(ax, x+.68, y+h-.35, title, 19, weight='bold')

def diagram_cells(ax, values, x, y, pitch, width, height=.43, *, highlighted=None,
          conflicts=None, size=18):
    highlighted, conflicts = highlighted or {}, conflicts or set()
    for j, value in enumerate(values):
        fill = highlighted.get(j, C['gray'] if value == '?' else 'white')
        edge = C['red'] if j in conflicts else C['line']
        if j in conflicts:
            fill = C['redbg']
        rect(ax, x+j*pitch, y-height/2, width, height,
             fill=fill, edge=edge, lw=2 if j in conflicts else 1.3, rounding=.035)
        txt(ax, x+j*pitch+width/2, y, value, size, ha='center',
            weight='bold' if j in conflicts or j in highlighted else 'normal')

def draw_workflow():
    fig, ax = diagram_canvas(10.4, 'FindHap: filling genotype gaps with shared haplotypes',
                     'FindHap and TurboHap infer haplotype pairs within short chromosome segments.')
    diagram_panel(ax, .4, 4.18, 13.2, 4.65, 'A', 'One animal, one segment: a compatible haplotype pair')
    observed = ['AA', 'AB', '?', 'BB', 'AB']
    first, second = list('AABBA'), list('ABBBB')
    completed = [''.join(sorted(pair)) for pair in zip(first, second)]
    assert all(old == '?' or old == new for old, new in zip(observed, completed))
    assert completed == ['AA', 'AB', 'BB', 'BB', 'AB']
    x, pitch, width = 3.3, 1.02, .83
    for j in range(5):
        txt(ax, x+j*pitch+width/2, 7.86, f'Locus {j+1}', 16, ha='center', color=C['muted'])
    rows = [('Observed genotype', observed, 7.23, {}),
            ('Haplotype 1', first, 6.35, {j:C['bluebg'] for j in range(5)}),
            ('Haplotype 2', second, 5.76, {j:C['tealbg'] for j in range(5)}),
            ('Imputed genotype', completed, 4.84, {2:C['greenbg']})]
    for label, values, y, highlights in rows:
        txt(ax, .72, y, label, 17, weight='bold' if y == 4.84 else 'normal')
        diagram_cells(ax, values, x, y, pitch, width, highlighted=highlights)
    arrow(ax, (5.75, 6.94), (5.75, 6.63), color=C['teal'], lw=2.1)
    arrow(ax, (5.75, 5.47), (5.75, 5.12), color=C['teal'], lw=2.1)
    txt(ax, 9.12, 7.23, '? = a missing call', 17, color=C['muted'])
    txt(ax, 9.12, 6.06, 'The two haplotypes agree\nwith every observed call.', 17)
    txt(ax, 9.12, 4.84, 'The pair fills the gap: BB', 17, color=C['green'], weight='bold')
    txt(ax, .73, 4.43, 'One illustrative pair from the shared segment library; other compatible pairs may exist.',
        15.5, color=C['muted'])

    diagram_panel(ax, .4, .65, 13.2, 3.15, 'B', 'Across the population: genotypes + marker map + pedigree')
    cards = [(.74, 3.72, 'Build the library', 'Start with higher-density\nanimals.', C['bluebg'], C['blue']),
             (4.79, 3.72, 'Match more animals', 'Include lower-density data\nin later passes.', C['tealbg'], C['teal']),
             (8.84, 4.02, 'Refine with relatives', 'Check inheritance\nand crossovers.', C['purplebg'], C['purple'])]
    for x, w, title, body, fill, color in cards:
        rect(ax, x, 1.65, w, 1.40, fill=fill, edge=color, lw=1.7)
        txt(ax, x+w/2, 2.70, title, 18, weight='bold', ha='center')
        txt(ax, x+w/2, 2.13, body, 16.5, ha='center')
    arrow(ax, (4.50, 2.35), (4.75, 2.35), lw=2.1)
    arrow(ax, (8.55, 2.35), (8.80, 2.35), lw=2.1)
    route(ax, [(10.85,1.63),(10.85,1.30),(6.65,1.30),(6.65,1.63)], color=C['teal'], lw=2)
    txt(ax, 6.98, .96, 'Repeat matching and pedigree refinement within each segment length.',
        16, color=C['teal'], ha='center')
    txt(ax, .4, .25, 'Carry information between segment lengths. Saved haplotypes can be written at each step and reused later.',
        15.5, color=C['muted'])
    return fig

def workflow():
    # All three figures use the approved 22 October revisions.
    with plt.rc_context({'font.size': 17, 'svg.hashsalt': 'turbohap-methods-preview-v2'}):
        save(draw_workflow(), 'turbohap_findhap_workflow', date='221026', dpi=180,
             creator='TurboHap methods preview renderer')


def draw_candidate_search():
    fig, ax = diagram_canvas(10.4, 'TurboHap: the same match with fewer detailed checks',
                     'A cheap conflict filter reduces work; surviving candidates keep their original order.')
    diagram_panel(ax, .4, 4.90, 13.2, 3.92, 'A', 'First four candidates; eight positions from a longer segment')
    start, pitch, width = 3.60, .64, .49
    sampled = {0,2,4,6}
    for j in range(8):
        x = start+j*pitch
        if j in sampled:
            rect(ax, x-.035, 5.05, width+.07, 2.98, fill=C['bluebg'], edge=C['bluebg'], rounding=.035)
        txt(ax, x+width/2, 7.96, str(j+1), 15.5, ha='center', color=C['muted'])
    query = list('ABABABAB')
    haps = [list('ABABABBB'), list('AAABABAB'), list('ABAB?BAB'), list('ABABABAB')]
    conflicts = lambda row, sites: sum(row[j] != '?' and row[j] != query[j] for j in sites)
    assert [conflicts(row,sampled) for row in haps] == [1,0,0,0]
    assert [conflicts(row,range(8)) for row in haps] == [1,1,0,0]
    assert min(range(3), key=lambda j: ([3,3,9][j], j)) == 0
    data = [('Animal\'s allele\nconstraints', query, 7.35, set(), 'Known alleles required by the animal'),
            ('H1', haps[0], 6.80, {6}, 'Conflict at a sampled position'),
            ('H2', haps[1], 6.25, {1}, 'Conflict outside sampled positions'),
            ('H3', haps[2], 5.70, set(), 'First compatible match'),
            ('H4', haps[3], 5.15, set(), 'Search has already stopped')]
    for label, row, y, bad, note in data:
        txt(ax, .75, y, label, 16.5, weight='bold')
        diagram_cells(ax, row, start, y, pitch, width, height=.40, conflicts=bad, size=17)
        txt(ax, 9.04, y, note, 16, color=C['green'] if label=='H3' else C['muted'],
            weight='bold' if label=='H3' else 'normal')

    for x, letter, title, subtitle, turbo in [
            (.4,'B','Fortran','Enter the original check for each candidate.',False),
            (7.1,'C','TurboHap','Reject H1 from the sampled positions alone.',True)]:
        diagram_panel(ax, x, 1.72, 6.5, 2.78, letter, title)
        txt(ax, x+.25, 3.60, subtitle, 16)
        for j in range(3):
            xx = x+.50+j*1.95
            accepted = j==2
            cheap = turbo and j==0
            fill = C['greenbg'] if accepted else C['gray'] if cheap else C['bluebg']
            edge = C['green'] if accepted else C['red']
            rect(ax, xx, 2.55, 1.45, .65, fill=fill, edge=edge, lw=1.8)
            txt(ax, xx+.725, 2.875, 'H'+str(j+1), 19, ha='center', weight='bold')
            txt(ax, xx+.725, 2.30, 'Filter reject' if cheap else 'Detailed check', 14.5, ha='center',
                color=C['red'] if cheap else C['muted'])
            if j<2:arrow(ax,(xx+1.48,2.875),(xx+1.90,2.875),lw=2)
        txt(ax, x+3.25, 1.96, '2 detailed checks; accept H3' if turbo else '3 detailed checks; accept H3',
            17, ha='center', weight='bold', color=C['green'] if turbo else C['ink'])
    txt(ax, .5, 1.25, 'Blue = sampled positions; ? = unknown. Zero-conflict example; both programs can stop a check early.',
        15.5, color=C['muted'])
    rect(ax, .4, .23, 13.2, .72, fill=C['tealbg'], edge=C['teal'])
    txt(ax, 7, .59, 'Skipping a candidate still preserves its role in frequency counts and order updates.',
        16, ha='center', color=C['teal'])
    return fig

def candidate_search():
    with plt.rc_context({'font.size': 17, 'svg.hashsalt': 'turbohap-methods-preview-v2'}):
        save(draw_candidate_search(), 'turbohap_exact_candidate_search', date='221026', dpi=180,
             creator='TurboHap methods preview renderer')


def segment_work(ax, x, y):
    rect(ax, x, y, 1.65, .98, fill='white', edge=C['muted'], lw=1.5)
    for j, color in enumerate(['blue','teal','purple']):
        yy = y+.73-j*.285
        rect(ax, x+.10, yy-.10, 1.45, .225, fill=C[color+'bg'], edge=C[color], rounding=.025)
        txt(ax, x+.825, yy+.0125, 'Segment '+str(j+1), 14.5, ha='center')


def draw_storage_parallel():
    fig, ax = diagram_canvas(10.4, 'TurboHap: compact storage and reusable workers',
                     'The genotype values and inference decisions are preserved.')
    diagram_panel(ax,.4,5.97,6.35,2.87,'A','Pack the genotype calls')
    calls = ['BB','AB','AA','?','AA','AB','BB','?']
    bits = ['00','01','10','11','10','01','00','11']
    assert [{ '00':'BB','01':'AB','10':'AA','11':'?' }[b] for b in bits] == calls
    txt(ax,.68,7.89,'Calls',17)
    txt(ax,.68,7.19,'Bits',17)
    for values,y,fill in [(calls,7.89,C['bluebg']),(bits,7.19,C['tealbg'])]:
        diagram_cells(ax,values,2.12,y,.53,.45,height=.45,highlighted={j:fill for j in range(8)},size=16)
    arrow(ax,(4.17,7.61),(4.17,7.49),color=C['teal'])
    txt(ax,.68,6.65,'8 genotype bytes → 2 packed bytes',18,weight='bold')
    txt(ax,.68,6.20,'Genotype payload only; other values keep byte storage.',14.5,color=C['muted'])

    diagram_panel(ax,7.05,5.97,6.55,2.87,'B','Choose where genotypes live')
    txt(ax,8.75,8.00,'TurboHap',18,weight='bold',ha='center',color=C['blue'])
    txt(ax,11.95,8.00,'TurboHap LM',18,weight='bold',ha='center',color=C['purple'])
    rect(ax,7.55,6.43,2.40,1.28,fill=C['bluebg'],edge=C['blue'])
    txt(ax,8.75,7.07,'Packed genotypes\nin RAM',17,ha='center')
    rect(ax,10.75,7.24,2.40,.50,fill=C['purplebg'],edge=C['purple'])
    txt(ax,11.95,7.49,'Files on disk',17,ha='center')
    rect(ax,10.75,6.35,2.40,.54,fill=C['purplebg'],edge=C['purple'])
    txt(ax,11.95,6.62,'Small batch in RAM',16.5,ha='center')
    exchange = arrow(ax,(11.95,7.18),(11.95,6.95),color=C['purple'],style='<->',lw=2)
    exchange.set_mutation_scale(10)
    txt(ax,10.325,6.15,'Libraries and assignments stay in RAM in both modes.',14.5,ha='center',color=C['muted'])

    diagram_panel(ax,.4,.68,13.2,4.85,'C','Pedigree processing: reuse workers across animals')
    txt(ax,.75,4.68,'Both programs process chromosome segments in parallel and retain animal order.',17,color=C['muted'])
    positions = [3.97,7.12,10.27]
    for j,x in enumerate(positions):
        txt(ax,x+.825,4.20,'Animal '+str(j+1),17,ha='center',weight='bold')
    txt(ax,.75,3.52,'Fortran',19,weight='bold')
    txt(ax,.75,3.10,'Repeated setup',16,color=C['orange'])
    txt(ax,.75,2.08,'TurboHap',19,weight='bold',color=C['blue'])
    txt(ax,.75,1.65,'One setup',16,color=C['blue'])
    for x in [2.83,5.98,9.13]:
        rect(ax,x,3.02,.88,.98,fill='#fff1df',edge=C['orange'],lw=1.7)
        txt(ax,x+.44,3.51,'Set up\nwork',15.5,ha='center',color=C['orange'],weight='bold')
        arrow(ax,(x+.91,3.51),(x+1.10,3.51),lw=1.8)
    for x in positions:
        segment_work(ax,x,3.02)
    for x in [5.77,8.92]:
        ax.plot([x,x],[3.02,4.0],color=C['ink'],lw=2.4)
        arrow(ax,(x+.02,3.51),(x+.17,3.51),lw=1.6)

    rect(ax,2.67,1.44,9.55,1.20,fill=C['bluebg'],edge=C['blue'],lw=1.9)
    rect(ax,2.83,1.55,.88,.98,fill='#fff1df',edge=C['orange'],lw=1.7)
    txt(ax,3.27,2.04,'Set up\nwork',15.5,ha='center',color=C['orange'],weight='bold')
    arrow(ax,(3.75,2.04),(3.93,2.04),lw=1.8)
    for x in positions:
        segment_work(ax,x,1.55)
    for x in [5.77,8.92]:
        ax.plot([x,x],[1.55,2.53],color=C['ink'],lw=2.4)
        arrow(ax,(x+.05,2.04),(x+1.30,2.04),color=C['blue'],lw=2.2)
        txt(ax,x+.69,2.31,'Reuse',16,ha='center',color=C['blue'],weight='bold')
    txt(ax,7,1.03,'Black bars: finish all segments and share inheritance updates before the next animal.',
        15.5,ha='center',color=C['muted'])
    txt(ax,.4,.27,'Orange boxes mark parallel-region setup. Box widths are schematic, not measured durations.',
        15.5,color=C['muted'])
    return fig

def storage_parallel():
    with plt.rc_context({'font.size': 17, 'svg.hashsalt': 'turbohap-methods-preview-v2'}):
        save(draw_storage_parallel(), 'turbohap_storage_parallelism', date='221026', dpi=180,
             creator='TurboHap methods preview renderer')

if __name__=='__main__':
    workflow()
    candidate_search()
    storage_parallel()
    print('Rendered three figures as PNG, editable SVG and font-embedded PDF.')
