"""Read findhap's numeric records with the reference's list-directed syntax."""
import math
from pathlib import Path
import re
import struct

OPTION_NAMES = 'iters XChrom maxlen minlen steps maxhap hapout genout damout listout'.split()


def integer(token):
    if not re.fullmatch(r'[+-]?[0-9]+', token):
        raise ValueError(f'invalid integer: {token!r}')
    value = int(token)
    if not -(2**31) <= value < 2**31:
        raise ValueError(f'integer out of range: {token!r}')
    return value


def real(token):
    token = token.lower().replace('d', 'e')
    if 'e' not in token:
        token = re.sub(r'(?<=.)([+-])', r'e\1', token, count=1)
    if not re.fullmatch(r'[+-]?(?:([0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:e[+-]?[0-9]+)?|inf(?:inity)?|nan)', token):
        raise ValueError(f'invalid real: {token!r}')
    value = float(token)
    try:
        return struct.unpack('f', struct.pack('f', value))[0]
    except OverflowError:
        return math.copysign(math.inf, value)


class NumericRead:
    def __init__(self, records):
        self.records = records
        self.record = ''
        self.position = self.remaining = 0
        self.after_value = False
        self.repeated = ''

    def whitespace(self):
        while True:
            while self.position < len(self.record) and self.record[self.position] in ' \t\r':
                self.position += 1
            if self.position < len(self.record):
                return
            self.record = next(self.records, None)
            if self.record is None:
                raise ValueError('unexpected end of options record')
            self.position = 0

    def next(self):
        if self.remaining:
            self.remaining -= 1
            return self.repeated
        self.whitespace()
        if self.after_value and self.record[self.position] == ',':
            self.position += 1
            self.whitespace()
        if self.record[self.position] in ',/':
            raise ValueError('missing mandatory option value')
        start = self.position
        while self.position < len(self.record) and self.record[self.position] not in ' \t\r,/':
            self.position += 1
        token = self.record[start:self.position]
        if '*' in token:
            count, token = token.split('*', 1)
            if not re.fullmatch(r'[0-9]+', count) or integer(count) < 1 or not token:
                raise ValueError('invalid or null repetition')
            self.remaining = integer(count) - 1
            self.repeated = token
        self.after_value = True
        return token


def read_options(path):
    # split on physical newlines, not on other characters such as vertical tabs.
    with Path(path).open() as stream:
        records = iter(line.rstrip('\n') for line in stream)
        reader = NumericRead(records)
        result = dict(zip(OPTION_NAMES, (integer(reader.next()) for _ in OPTION_NAMES)))
        if next(records, None) is None or next(records, None) is None:
            raise ValueError('missing skipped option records')
        result['errate'] = real(NumericRead(records).next())
        return result
