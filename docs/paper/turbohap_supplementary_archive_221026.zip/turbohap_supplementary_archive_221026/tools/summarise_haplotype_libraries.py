#!/usr/bin/env python3
"""Extract the final positive-frequency haplotype counts from a FindHap log."""
import argparse
import hashlib
import json
from pathlib import Path
from statistics import median


def final_libraries(text):
    lines = text.splitlines()
    headings = [i for i, line in enumerate(lines)
                if 'Number of haplotypes found within each segment' in line]
    if len(headings) != 1:
        raise ValueError('Expected one final haplotype-count table')
    start = next(i for i in range(headings[0] + 1, len(lines))
                 if lines[i].strip() == 'Chrome') + 1
    rows = []
    for chromosome, line in enumerate(lines[start:], 1):
        if not line.strip():
            break
        fields = line.split()
        if len(fields) < 2 or not all(s.isdigit() for s in fields):
            raise ValueError('Incomplete or truncated haplotype-count row')
        values = [int(s) for s in fields]
        if values[0] != chromosome:
            raise ValueError('Chromosome rows are missing or out of order')
        rows.append({'chromosome': chromosome, 'counts': values[1:]})
    if len(rows) != 30:
        raise ValueError('Expected 30 chromosomes for this benchmark study')
    counts = [v for row in rows for v in row['counts']]
    return {'final_step_segments': len(counts), 'minimum_active_haplotypes': min(counts),
            'median_active_haplotypes': median(counts),
            'maximum_active_haplotypes': max(counts), 'chromosomes': rows}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('log', type=Path)
    args = parser.parse_args()
    raw = args.log.read_bytes()
    result = final_libraries(raw.decode())
    result['log_sha256'] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
