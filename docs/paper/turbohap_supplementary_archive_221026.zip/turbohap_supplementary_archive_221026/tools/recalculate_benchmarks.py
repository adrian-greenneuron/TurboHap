#!/usr/bin/env python3
"""Check the supplementary payload and recalculate published aggregate results."""
import csv
import hashlib
import json
from pathlib import Path
from statistics import median
import sys

ROOT = Path(__file__).resolve().parents[1]
BASE = 'turbohap_benchmarks_221026'
PROGRAMS = ('Fortran baseline', 'TurboHap', 'TurboHap LM')


def load_observations(root=ROOT):
    data = json.loads((root / 'data' / (BASE + '.json')).read_text())
    observations = data['observations']
    manifest = json.loads((root / 'data/turbohap_benchmark_datasets_221026.json').read_text())
    if len(observations) != 42 or len(manifest['datasets']) != 7:
        raise ValueError('Expected seven datasets and 42 observations')
    datasets = [d['dataset'] for d in manifest['datasets']]
    if len(set(datasets)) != 7 or {r['dataset'] for r in observations} != set(datasets):
        raise ValueError('Dataset labels differ between observations and manifest')
    for d in manifest['datasets']:
        if d['dataset'] != f"{d['genotyped_animals']:,} × {d['map_loci']:,}":
            raise ValueError('Dataset dimensions do not match label')
    with (root / 'data' / (BASE + '.csv')).open(newline='') as f:
        rows = list(csv.DictReader(f))
    # Compare parsed numeric values without discarding precision or changing order.
    if len(rows) != len(observations):
        raise ValueError('CSV and JSON row counts differ')
    for csv_row, row in zip(rows, observations):
        if set(csv_row) != set(row):
            raise ValueError('CSV and JSON fields differ')
        for key, value in row.items():
            parsed = type(value)(csv_row[key])
            if parsed != value:
                raise ValueError(f'CSV/JSON disagreement: {key}')
    if {r['program'] for r in observations} != set(PROGRAMS):
        raise ValueError('Unexpected program labels')
    for dataset in datasets:
        for program in PROGRAMS:
            runs = [r for r in observations if r['dataset'] == dataset and r['program'] == program]
            if len(runs) != 2 or {r['repeat'] for r in runs} != {1, 2}:
                raise ValueError('Expected repeats 1 and 2 for every condition')
            if not all(r['wall_seconds'] > 0 and r['peak_rss_kib'] > 0
                       and r['swaps'] == 0 and r['output_check'].startswith('pass') for r in runs):
                raise ValueError('Invalid or unsuccessful observation')
    return datasets, observations


def summaries(datasets, observations):
    result = []
    for dataset in datasets:
        medians = {}
        for program in PROGRAMS:
            rows = [r for r in observations if r['dataset'] == dataset and r['program'] == program]
            medians[program] = (median(r['wall_seconds'] for r in rows),
                                median(r['peak_rss_kib'] for r in rows) / 1048576)
        baseline_time, baseline_rss = medians[PROGRAMS[0]]
        for program in PROGRAMS:
            seconds, gib = medians[program]
            result.append(dict(dataset=dataset, program=program, median_seconds=seconds,
                               median_peak_rss_gib=gib, speedup=baseline_time / seconds,
                               memory_change_percent=100 * (gib / baseline_rss - 1)))
    return result


def verify_checksums(root=ROOT):
    checksum_file = root / 'SHA256SUMS'
    expected = set()
    for line in checksum_file.read_text().splitlines():
        digest, relative = line.split('  ', 1)
        path = (root / relative).resolve()
        if not path.is_relative_to(root.resolve()) or relative in expected:
            raise ValueError('Invalid or duplicate checksum path')
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError(f'Checksum mismatch: {relative}')
        expected.add(relative)
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*')
              if p.is_file() and p.name != 'SHA256SUMS' and '__pycache__' not in p.parts}
    if actual != expected:
        raise ValueError('Archive inventory differs from SHA256SUMS')


def verify_library_summaries(root=ROOT):
    manifest = json.loads((root / 'data/turbohap_benchmark_datasets_221026.json').read_text())
    libraries = json.loads((root / 'data/turbohap_haplotype_libraries_221026.json').read_text())
    expected = manifest['datasets']
    if [r['dataset'] for r in libraries['datasets']] != [d['dataset'] for d in expected]:
        raise ValueError('Library-count dataset labels differ')
    with (root / 'data/turbohap_haplotype_libraries_221026.csv').open(newline='') as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 7:
        raise ValueError('Expected seven library summaries')
    for row, library, dataset in zip(rows, libraries['datasets'], expected):
        counts = [n for chrom in library['chromosomes'] for n in chrom['counts']]
        if [c['chromosome'] for c in library['chromosomes']] != list(range(1, 31)):
            raise ValueError('Expected 30 ordered chromosome rows')
        if not counts or not all(isinstance(n, int) and n >= 0 for n in counts):
            raise ValueError('Invalid library counts')
        actual = (len(counts), min(counts), median(counts), max(counts))
        recorded = tuple(library[k] for k in ('final_step_segments', 'minimum_active_haplotypes',
                                             'median_active_haplotypes', 'maximum_active_haplotypes'))
        if actual != recorded or library['maxhap'] != dataset['findhap_options']['maxhap']:
            raise ValueError('Library summary differs from counts or configured capacity')
        for key, value in row.items():
            if type(library[key])(value) != library[key]:
                raise ValueError('Library CSV/JSON disagreement')
        if len(library['logs']) != 6 or not library['all_six_run_logs_agree']:
            raise ValueError('Expected agreement across six run logs')


def main():
    verify_checksums()
    verify_library_summaries()
    datasets, observations = load_observations()
    rows = summaries(datasets, observations)
    out = csv.DictWriter(sys.stdout, fieldnames=list(rows[0]), lineterminator='\n')
    out.writeheader()
    out.writerows(rows)
    print('Verified payload checksums, 42 observations and seven final-library summaries.',
          file=sys.stderr)


if __name__ == '__main__':
    main()
