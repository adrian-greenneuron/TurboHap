#!/usr/bin/env python3
"""Rerun one benchmark dataset with Fortran, TurboHap and LM, twice each.

Linux, GNU time and GNU sort are required. Results and all output files are
retained in a new work directory. This utility creates new measurements;
it does not replace the observations supplied with the manuscript.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

from compare_outputs import INPUTS, OUTPUTS, compare_directories
from findhap_options import read_options

DATA_FILES = ('chromosome.data', 'genotypes.txt', 'pedigree.file', 'findhap.options')


def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return {'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}


def run_dataset(dataset, baseline, turbohap, work, threads=10):
    dataset, baseline, turbohap, work = [Path(p).resolve()
                                        for p in (dataset, baseline, turbohap, work)]
    if not 1 <= threads <= 99:
        raise ValueError('Thread count must be between 1 and 99')
    inputs = {name: dataset / name for name in DATA_FILES}
    for path in [*inputs.values(), baseline, turbohap]:
        if not path.is_file():
            raise ValueError(f'Missing input or executable: {path}')
    for binary in (baseline, turbohap):
        if not os.access(binary, os.X_OK):
            raise ValueError(f'Not executable: {binary}')
    if any((dataset / name).exists()
           for name in ('hap.listpriors', 'hap.foundpriors', 'hap.Xseg')):
        raise ValueError('This benchmark utility expects datasets without priors')
    options = read_options(inputs['findhap.options'])
    programs = [('Fortran baseline', baseline, []),
                ('TurboHap', turbohap, []),
                ('TurboHap LM', turbohap, ['--low-memory'])]
    if not Path('/usr/bin/time').is_file() or not Path('/usr/bin/sort').is_file():
        raise ValueError('GNU time and GNU sort are required in /usr/bin')
    record = {'created_utc': datetime.now(timezone.utc).isoformat(),
              'threads': threads, 'options': options,
              'inputs': {name: identity(path) for name, path in inputs.items()},
              'binaries': {'Fortran baseline': identity(baseline),
                           'TurboHap': identity(turbohap)},
              'environment': {'LC_ALL': 'C', 'OMP_DYNAMIC': 'FALSE',
                              'OMP_NUM_THREADS': str(threads)},
              'cpu_affinity': sorted(os.sched_getaffinity(0)),
              'runs': [], 'passed': False}
    work.mkdir(parents=True, exist_ok=False)
    output = work / 'results.json'

    def save():
        output.write_text(json.dumps(record, indent=2) + '\n')

    save()
    env = dict(os.environ, **record['environment'])
    golden, cpp_hashes = None, None
    for repeat, order in [(1, programs), (2, list(reversed(programs)))]:
        for label, binary, arguments in order:
            slug = {'Fortran baseline': 'fortran', 'TurboHap': 'turbohap',
                    'TurboHap LM': 'lm'}[label]
            name = f'repeat-{repeat}-{slug}'
            directory = work / name
            directory.mkdir()
            for filename, source in inputs.items():
                if filename == 'findhap.options':
                    shutil.copyfile(source, directory / filename)
                else:
                    (directory / filename).symlink_to(source)
            metrics = work / (name + '.time')
            command = ['/usr/bin/time', '-f', '%U %S %M %W %I %O %F',
                       '-o', str(metrics), str(binary), str(threads), *arguments]
            print('Running', name, flush=True)
            with (directory / 'stdout.log').open('wb') as out, \
                    (directory / 'stderr.log').open('wb') as err:
                start = time.perf_counter()
                process = subprocess.run(command, cwd=directory, env=env,
                                         stdout=out, stderr=err)
                elapsed = time.perf_counter() - start
            run = {'program': label, 'repeat': repeat, 'wall_seconds': elapsed,
                   'returncode': process.returncode}
            record['runs'].append(run)
            save()
            if process.returncode or b'Program findhap completed normally' not in \
                    (directory / 'stdout.log').read_bytes():
                raise RuntimeError(f'Program failed: {directory}')
            user, system, rss, swaps, reads, writes, faults = metrics.read_text().split()
            run.update(user_seconds=float(user), system_seconds=float(system),
                       peak_rss_kib=int(rss), swaps=int(swaps),
                       filesystem_inputs=int(reads), filesystem_outputs=int(writes),
                       major_page_faults=int(faults))
            comparison = compare_directories(golden or directory, directory, options,
                                             allow_crossover_reordering=True)
            (work / (name + '.comparison.json')).write_text(
                json.dumps(comparison, indent=2) + '\n')
            run['comparison_passed'] = comparison['passed']
            run['outputs'] = {p.name: identity(p) for p in directory.iterdir()
                              if p.is_file() and (p.name in OUTPUTS or p.name not in
                              INPUTS | {'stdout.log', 'stderr.log'})}
            save()
            if not comparison['passed']:
                raise RuntimeError(f'Output mismatch: {directory}')
            if label != 'Fortran baseline':
                if cpp_hashes is None:
                    cpp_hashes = run['outputs']
                run['strict_cpp_match'] = run['outputs'] == cpp_hashes
                save()
                if not run['strict_cpp_match']:
                    raise RuntimeError(f'C++ repeat/mode mismatch: {directory}')
            if golden is None:
                golden = directory
            print('PASS', name, f'{elapsed:.3f}s', flush=True)
    if any(identity(path) != record['inputs'][name] for name, path in inputs.items()):
        raise RuntimeError('Input files changed during measurement')
    if identity(baseline) != record['binaries']['Fortran baseline'] or \
            identity(turbohap) != record['binaries']['TurboHap']:
        raise RuntimeError('Executables changed during measurement')
    record['passed'] = True
    save()
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dataset', type=Path, required=True)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--turbohap', type=Path, required=True)
    parser.add_argument('--work-dir', type=Path, required=True)
    parser.add_argument('--threads', type=int, default=10)
    args = parser.parse_args()
    try:
        run_dataset(args.dataset, args.baseline, args.turbohap, args.work_dir, args.threads)
    except (OSError, ValueError, RuntimeError, subprocess.CalledProcessError) as exc:
        parser.exit(1, f'{exc}\n')


if __name__ == '__main__':
    main()
