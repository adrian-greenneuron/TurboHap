#!/usr/bin/env python3
"""Compare findhap outputs, strictly by default; optionally allow crossover record reordering."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
from findhap_options import read_options

OUTPUTS = (
    'allele.frequency', 'cross.overs', 'do_not_distrib', 'genotypes.filled',
    'hap.filled', 'hap.found', 'hap.inherit', 'hap.list', 'hap.Xseg', 'haplotypes.txt',
)
OPTIONAL_OUTPUTS = {'genotypes.filled', 'haplotypes.txt', 'hap.list', 'hap.found'}
INPUTS = {'chromosome.data', 'genotypes.txt', 'pedigree.file', 'findhap.options',
          'hap.listpriors', 'hap.foundpriors', 'hap.Xseg'}


def expected_outputs(options=None):
    if options is None:
        return set(OUTPUTS)
    expected = set(OUTPUTS) - OPTIONAL_OUTPUTS
    if options['genout'] > 0:
        expected.add('genotypes.filled')
    if options['hapout'] > 0:
        expected.add('haplotypes.txt')
    if options['listout'] != 0:
        expected.update(('hap.list', 'hap.found'))
    return expected


def compare_file(reference, candidate):
    """Stream files, retaining hashes and the first differing byte (1-based)."""
    reference, candidate = Path(reference), Path(candidate)
    result = {'file': reference.name}
    present = [p.is_file() for p in (reference, candidate)]
    if not all(present):
        result.update(status='missing', reference_exists=present[0], candidate_exists=present[1])
        return result
    hashes = [hashlib.sha256(), hashlib.sha256()]
    sizes = [0, 0]
    first = None
    line, column = 1, 1
    with reference.open('rb') as a, candidate.open('rb') as b:
        while True:
            chunks = [a.read(1024 * 1024), b.read(1024 * 1024)]
            if not any(chunks):
                break
            if first is None and chunks[0] != chunks[1]:
                offset = next((i for i, (x, y) in enumerate(zip(*chunks)) if x != y),
                              min(map(len, chunks)))
                prefix = chunks[0][:offset]
                newlines = prefix.count(b'\n')
                first = {'byte': sizes[0] + offset + 1,
                         'reference_line': line + newlines,
                         'reference_column': len(prefix.rsplit(b'\n', 1)[-1]) + 1 if newlines else column + offset,
                         'reference_byte': chunks[0][offset] if offset < len(chunks[0]) else None,
                         'candidate_byte': chunks[1][offset] if offset < len(chunks[1]) else None}
            for i, chunk in enumerate(chunks):
                hashes[i].update(chunk)
                sizes[i] += len(chunk)
            newlines = chunks[0].count(b'\n')
            line += newlines
            column = len(chunks[0].rsplit(b'\n', 1)[-1]) + 1 if newlines else column + len(chunks[0])
    result.update(status='identical' if first is None else 'different',
                  reference_size=sizes[0], candidate_size=sizes[1],
                  reference_sha256=hashes[0].hexdigest(), candidate_sha256=hashes[1].hexdigest())
    if first is not None:
        result['first_difference'] = first
    return result


def same_crossover_records(reference, candidate):
    """Keep the header and every record byte exact, including duplicate counts.

    External sorting bounds memory on large datasets. The original files are
    untouched. Require newline-terminated records so sort cannot silently
    repair a missing final newline.
    """
    if reference.stat().st_size != candidate.stat().st_size:
        return False
    with reference.open('rb', buffering=0) as a, candidate.open('rb', buffering=0) as b:
        headers = [stream.readline() for stream in (a, b)]
        if headers[0] != headers[1]:
            return False
        for stream, header in zip((a, b), headers):
            if stream.seek(0, os.SEEK_END):
                stream.seek(-1, os.SEEK_END)
                if stream.read(1) != b'\n':
                    return False
            stream.seek(len(header))
        with tempfile.TemporaryDirectory(prefix='findhap-crossovers-') as temporary:
            ordered = [Path(temporary) / name for name in ('reference', 'candidate')]
            env = dict(os.environ, LC_ALL='C')
            for stream, destination in zip((a, b), ordered):
                with destination.open('wb') as output:
                    subprocess.run(['/usr/bin/sort', '--parallel=1', '-S', '128M', '-T', temporary],
                                   stdin=stream, stdout=output, stderr=subprocess.PIPE,
                                   env=env, check=True)
            return compare_file(*ordered)['status'] == 'identical'


def compare_directories(reference, candidate, options=None, allow_crossover_reordering=False):
    reference, candidate = Path(reference), Path(candidate)
    if not reference.is_dir() or not candidate.is_dir():
        raise ValueError('Both run directories must exist')
    expected = expected_outputs(options)
    # Include unexpected output files, notably Fortran's implicit fort.26.
    ignored = INPUTS | {'stdout.log', 'stderr.log'}
    extras = {p.name for folder in (reference, candidate) for p in folder.iterdir()
              if p.name not in ignored}
    results = []
    for name in sorted(set(OUTPUTS) | extras):
        if name not in expected and not (reference / name).exists() and not (candidate / name).exists():
            results.append({'file': name, 'status': 'disabled'})
        else:
            result = compare_file(reference / name, candidate / name)
            if (allow_crossover_reordering and name == 'cross.overs' and
                    result['status'] == 'different' and
                    same_crossover_records(reference / name, candidate / name)):
                result.update(status='reordered', raw_status='different')
            results.append(result)
    return {'passed': all(r['status'] in {'identical', 'disabled', 'reordered'} for r in results),
            'byte_identical': all(r['status'] in {'identical', 'disabled'} for r in results),
            'comparison_policy': 'crossover-order' if allow_crossover_reordering else 'strict-bytes',
            'files': results}


def print_result(result):
    for item in result['files']:
        detail = ''
        if 'first_difference' in item:
            diff = item['first_difference']
            detail = f" at byte {diff['byte']} (reference line {diff['reference_line']}, column {diff['reference_column']})"
        print(f"{item['file']:<20} {item['status'].upper()}{detail}")
    if result.get('byte_identical', result['passed']):
        print('PASS: all enabled outputs are byte-identical')
    elif result['passed']:
        print('PASS with ordering exception: only cross.overs record order differs; not a strict byte pass')
    else:
        print('FAIL: missing or different output files')


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('reference', type=Path)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('--options', type=Path, help='Options used by both runs; otherwise require all ten outputs')
    parser.add_argument('--json', type=Path, help='Write machine-readable comparison')
    parser.add_argument('--allow-crossover-reordering', action='store_true',
                        help='Allow only cross.overs record order to differ; preserve all bytes and duplicate counts')
    args = parser.parse_args(argv)
    try:
        result = compare_directories(args.reference, args.candidate,
                                     read_options(args.options) if args.options else None,
                                     args.allow_crossover_reordering)
        print_result(result)
        if args.json:
            args.json.write_text(json.dumps(result, indent=2) + '\n')
        return 0 if result['passed'] else 1
    except (OSError, ValueError, subprocess.CalledProcessError) as exc:
        parser.exit(2, f'ERROR: {exc}\n')


if __name__ == '__main__':
    raise SystemExit(main())
